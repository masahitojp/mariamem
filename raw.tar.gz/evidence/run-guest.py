import json,subprocess,time
from pathlib import Path
w=Path(__file__).resolve().parents[1]
cmd=json.loads((w/"evidence/guest-command.json").read_text())
start=time.time()
with (w/"evidence/guest-build.log").open("w") as log:
 r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(w/"evidence/guest-exit.json").write_text(json.dumps({"exit_code":r.returncode,"elapsed_seconds":time.time()-start})+"\n")
raise SystemExit(r.returncode)

from pathlib import Path
import json,hashlib,subprocess,platform
w=Path(__file__).resolve().parents[1];e=w/'evidence'
for name in ['measure/main.go','common/common.go']:
 p=e/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((e/'prior'/name).read_bytes())
s=(e/'prior/compare.py').read_text()
a=s.index('    identity = ');b=s.index('    records=[]',a)
prefix='''    plan = json.loads((E/'comparison-plan.json').read_text())
    for name, expected in plan['sources_sha256'].items():
        assert sha(E/name) == expected
    env = {k:v for k,v in os.environ.items() if not k.startswith(
        ('MARIAMEM_','MYSQLMEM_','GO','GODEBUG','GOMEMLIMIT','GOGC'))}
    env.update(GOTOOLCHAIN='go1.26.10', GOWORK='off', GOENV='off', CGO_ENABLED='0',
               GOMAXPROCS='8', GOCACHE=str(T/'gocache'), GOMODCACHE=str(T/'modcache'),
               GOTMPDIR=str(T/'go-tmp'), TMPDIR=str(T/'tmp'))
    for name in ['go-tmp','tmp','bin']:(T/name).mkdir(parents=True,exist_ok=True)
    guard = DiskGuard(W, min_free_gib=12, budget_gib=6)
    roots = {name:T/(name+'-product') for name in ['baseline','candidate']}
    before={}; identities={}
    for name,root in roots.items():
        commit=plan[name+'_source_commit']; require_commit(C,commit)
        if root.exists():raise AssertionError('fresh clone required: '+str(root))
        subprocess.run(['git','clone','--shared','--no-checkout',str(C),str(root)],check=True)
        subprocess.run(['git','checkout','--detach',commit],cwd=root,check=True)
        identity = subprocess.check_output([sys.executable,str(C/'scripts/git_identity.py'),'inspect','HEAD'],cwd=root,text=True)
        # Inspect explicitly against the clone, not the report worktree's ROOT.
        from git_identity import inspect_ref
        parsed=inspect_ref(root,'HEAD');assert parsed.object_type=='commit' and parsed.source_commit==commit
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
        identities[name]={'source_commit':commit,'object_type':parsed.object_type}
        before[name]={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts}
    differences=[p for p in sorted(set(before['baseline'])|set(before['candidate'])) if before['baseline'].get(p)!=before['candidate'].get(p)]
    go_differences=[p for p in differences if p.endswith(('.go','.s'))]
    assert go_differences and all(p.startswith('internal/generatedgo/') or p=='internal/runtimekind/kind.go' for p in go_differences),go_differences
    assert subprocess.check_output(['go','version'],env=env,text=True).strip() == 'go version go1.26.10 darwin/arm64'
    inputs = {'source_identities':identities,'baseline_guest_sha256':json.loads((roots['baseline']/'release/generated-go-inputs.json').read_text())['guest_sha256'],
              'candidate_guest_sha256':json.loads((roots['candidate']/'release/generated-go-inputs.json').read_text())['guest_sha256'],
              'plan_sha256':sha(E/'comparison-plan.json'),'source_differences':differences,'go_differences':go_differences,
              'source_inventories':before,'harness_sha256':plan['sources_sha256'],'binaries':{},
              'go':'go1.26.10 darwin/arm64','CGO_ENABLED':0,'GOMAXPROCS':8,
              'build_vcs':False,'build_vcs_reason':'Same checksum-bound untracked harness added to each clean pinned source; source identity and full inventory verified before and after. Not a release or normal host identity receipt.'}
    for mode,root in roots.items():
        target = root/'benchmarks/bufferalignmentsource'
        target.mkdir(parents=True, exist_ok=True)
        shutil.copy2(E/'measure/main.go',target/'main.go')
        shutil.copytree(E/'common',target/'common')
        binary = T/'bin'/mode
        cmd = ['go','build','-p','1','-mod=readonly','-trimpath','-buildvcs=false',
               '-o',str(binary),'./benchmarks/bufferalignmentsource']
        print('BUILD',mode,flush=True)
        with (E/('measure-build-'+mode+'.log')).open('w') as log:
            code = run_guarded(cmd,guard,cwd=root,env=env,output=log,timeout=1200)
        assert code == 0, (mode,code)
        inputs['binaries'][mode] = {'sha256':sha(binary),'command':cmd,
            'build_info':subprocess.check_output(['go','version','-m',str(binary)],env=env,text=True)}
    save(E/'measure-inputs.json',inputs)
'''
s=s[:a]+prefix+s[b:]
s=s.replace('        after=inventory(root)\n        assert all(after[n]==value for n,value in before[variant].items())',"        after={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts}\n        assert all(after[n]==value for n,value in before[variant].items())")
s=s.replace("         'workspace':guard.check()", "         'workspace':guard.check(),'scope':'post-merge measurement only; no new adoption decision'")
s=s.replace("        rec={'key':key", "        rec={'host_loadavg':list(os.getloadavg()),'key':key")
(e/'compare.py').write_text(s)
old=json.loads((e/'prior/comparison-plan.json').read_text())
old.update(baseline_source_commit='b7d4f90ece837a422d2ea8217dfd09a61ee7feaa',candidate_source_commit='ca7d6216bf662288ac326b693e9f272127657553',host_source_commit='each pinned canonical production source; shared unchanged measurement harness',candidate_source_commit_is_guest_origin=False)
old['sources_sha256']={n:hashlib.sha256((e/n).read_bytes()).hexdigest() for n in ['measure/main.go','common/common.go']}
old['result']='PLAN_BEFORE_POSTMERGE_MEASUREMENT';old['adoption']='Already approved/integrated scoped correction; this campaign measures rather than reopens adoption. Report opposing pairs; no significance claim.'
old['queue']='N/A, deliberately outside this remeasurement; no new probes or old Fn-anchor reuse.'
old['mechanism']='No observer or guest instrumentation; previously established mechanism is not re-measured.'
old['preflight_correction']='No previous run receipts reused; canonical pre-merge and merge source identities are independently checked.'
old['budget']={'active_minutes':60,'per_build_seconds':1200,'child_seconds':120,'disk_gib':6,'min_free_gib':12,'heavy_ci_runs':0}
(e/'comparison-plan.json').write_text(json.dumps(old,indent=2)+'\n')
print('Prepared same Go harness and finite 38-process plan; only runner input acquisition changed')

// Bounded source-candidate comparison; plain wall is never mixed with tracing.
package main

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"runtime"
	"sync"
	"syscall"
	"time"

	"github.com/masahitojp/mariamem"
	"github.com/masahitojp/mariamem/benchmarks/bufferalignmentsource/common"
	"github.com/masahitojp/mariamem/internal/generatedgo/code/base"
)

type Fork struct {
	WallMS float64 `json:"wall_ms"`
	CPUMS  float64 `json:"cpu_ms"`
}
type Result struct {
	Mode       string            `json:"mode"`
	Parallel   int               `json:"parallel"`
	Count      int               `json:"count"`
	BatchMS    float64           `json:"batch_ms"`
	Forks      []Fork            `json:"forks"`
	Success    bool              `json:"success"`
	Cleanup    bool              `json:"cleanup"`
	Error      string            `json:"error,omitempty"`
	Mapping    map[string]uint64 `json:"mapping_after_close"`
	Go         string            `json:"go"`
	GOMAXPROCS int               `json:"gomaxprocs"`
	Profile    any               `json:"profile"`
}

var input = bufio.NewReader(os.Stdin)

func checkpoint(name string) error {
	runtime.GC()
	time.Sleep(500 * time.Millisecond)
	fmt.Printf("{\"checkpoint\":%q}\n", name)
	_, err := input.ReadString('\n')
	return err
}
func cpu() float64 {
	var r syscall.Rusage
	if err := syscall.Getrusage(syscall.RUSAGE_SELF, &r); err != nil {
		panic(err)
	}
	return float64(r.Utime.Sec+r.Stime.Sec)*1000 + float64(r.Utime.Usec+r.Stime.Usec)/1000
}
func checkMutated(ctx context.Context, d *mariamem.Database) error {
	p, err := common.Connect(ctx, d)
	if err != nil {
		return err
	}
	var n, total int
	err = p.QueryRowContext(ctx, "SELECT COUNT(*),SUM(v) FROM fork_probe").Scan(&n, &total)
	if err == nil && (n != 1000 || total != 500501) {
		err = fmt.Errorf("mutation oracle %d %d", n, total)
	}
	return errors.Join(err, common.Disconnect(ctx, d, p))
}
func use(ctx context.Context, d *mariamem.Database, corrupt bool) (err error) {
	p, err := common.Connect(ctx, d)
	if err != nil {
		return err
	}
	defer func() { err = errors.Join(err, common.Disconnect(ctx, d, p)) }()
	if corrupt {
		_, err = p.ExecContext(ctx, "UPDATE fork_probe SET v=-1 WHERE id=1")
		if err != nil {
			return err
		}
	}
	if err = common.Oracle(ctx, p); err != nil {
		return err
	}
	if _, err = p.ExecContext(ctx, "UPDATE fork_probe SET v=v+1 WHERE id=1"); err != nil {
		return err
	}
	var v int
	err = p.QueryRowContext(ctx, "SELECT v FROM fork_probe WHERE id=1").Scan(&v)
	if err == nil && v != 2 {
		err = fmt.Errorf("updated v=%d", v)
	}
	return err
}
func one(ctx context.Context, sn *mariamem.Snapshot) (err error) {
	d, err := sn.Fork(ctx)
	if err != nil {
		return err
	}
	defer func() { err = errors.Join(err, d.Close()) }()
	return use(ctx, d, false)
}
func run(mode string, parallel int, corrupt bool) (r Result, err error) {
	r.Mode = mode
	r.Parallel = parallel
	r.Go = runtime.Version()
	r.GOMAXPROCS = runtime.GOMAXPROCS(0)
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	sn, err := common.Prepare(ctx)
	if err != nil {
		r.Mapping = base.MemoryMappingStats()
		r.Cleanup = r.Mapping["active_mappings"] == 0 && r.Mapping["active_rw_bytes"] == 0 && r.Mapping["active_reserved_bytes"] == 0
		r.Profile = common.Profile
		return r, err
	}
	r.Profile = common.Profile
	var children []*mariamem.Database
	defer func() {
		for _, d := range children {
			err = errors.Join(err, d.Close())
		}
		err = errors.Join(err, sn.Close())
		r.Mapping = base.MemoryMappingStats()
		r.Cleanup = r.Mapping["active_mappings"] == 0 && r.Mapping["active_rw_bytes"] == 0 && r.Mapping["active_reserved_bytes"] == 0
		if !r.Cleanup {
			err = errors.Join(err, fmt.Errorf("mapping cleanup: %v", r.Mapping))
		}
		r.Success = err == nil
		if err != nil {
			r.Error = err.Error()
		}
		if mode == "serial" {
			err = errors.Join(err, checkpoint("closed"))
		}
	}()
	if mode == "serial" {
		if err = checkpoint("baseline"); err != nil {
			return r, err
		}
		for i := 0; i < 4; i++ {
			c := cpu()
			w := time.Now()
			d, e := sn.Fork(ctx)
			wall := float64(time.Since(w).Nanoseconds()) / 1e6
			used := cpu() - c
			if e != nil {
				return r, e
			}
			children = append(children, d)
			r.Forks = append(r.Forks, Fork{wall, used})
			if err = use(ctx, d, corrupt && i == 0); err != nil {
				return r, err
			}
			r.Count++
			if err = checkpoint(fmt.Sprintf("child-%d", i+1)); err != nil {
				return r, err
			}
		}
		for _, d := range children {
			if err = checkMutated(ctx, d); err != nil {
				return r, err
			}
		}
	} else if mode == "batch" {
		jobs := make(chan int)
		errs := make(chan error, 48)
		var wg sync.WaitGroup
		start := time.Now()
		for i := 0; i < parallel; i++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				for range jobs {
					errs <- one(ctx, sn)
				}
			}()
		}
		for i := 0; i < 48; i++ {
			jobs <- i
		}
		close(jobs)
		wg.Wait()
		close(errs)
		r.BatchMS = float64(time.Since(start).Nanoseconds()) / 1e6
		r.Count = 48
		for e := range errs {
			err = errors.Join(err, e)
		}
	} else {
		return r, fmt.Errorf("unsupported mode %q", mode)
	}
	return r, err
}
func main() {
	mode := flag.String("mode", "serial", "serial or batch")
	p := flag.Int("parallel", 8, "batch parallelism")
	out := flag.String("out", "", "result path")
	bad := flag.Bool("corrupt", false, "negative oracle")
	flag.Parse()
	if (*p != 4 && *p != 8) || *out == "" {
		panic("explicit output and P4/P8 required")
	}
	r, err := run(*mode, *p, *bad)
	if err != nil {
		r.Error = err.Error()
		r.Success = false
	}
	data, e := json.MarshalIndent(r, "", "  ")
	if e != nil {
		panic(e)
	}
	if e = os.WriteFile(*out, append(data, '\n'), 0600); e != nil {
		panic(e)
	}
	if err != nil || !r.Success {
		os.Exit(1)
	}
}

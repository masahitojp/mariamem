"""Separate zero-fill pilot, after the plain finite campaign has finished."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

W=Path(__file__).resolve().parents[1];C=W/'worktree';T=W/'temp';E=W/'evidence'
sys.path.insert(0,str(C/'scripts'))
from experiment_disk import DiskGuard, run_guarded


def main():
    assert json.loads((E/'measure-complete.json').read_text())['result']=='PASS_MEASURED_FIELDS_ONLY'
    env={k:v for k,v in os.environ.items() if not k.startswith(('MARIAMEM_','MYSQLMEM_','GO'))}
    env.update(GOTOOLCHAIN='go1.26.10',GOWORK='off',GOENV='off',CGO_ENABLED='0',GOMAXPROCS='8',
               GOCACHE=str(T/'gocache'),GOMODCACHE=str(T/'modcache'),GOTMPDIR=str(T/'go-tmp'),TMPDIR=str(T/'tmp'))
    guard=DiskGuard(W,16,24)
    results={}
    for variant,root in [('baseline',T/'baseline-product'),('candidate',T/'dev-native-rebound/product')]:
        bench=root/'benchmarks/bufferalignment';bench.mkdir(parents=True)
        shutil.copy2(E/'observer-main.go',bench/'main.go');shutil.copytree(E/'common',bench/'common')
        base=root/'internal/generatedgo/code/base/base.go'
        observed=T/('observed-'+variant+'.go');shutil.copy2(base,observed)
        subprocess.run(['patch','--batch','--fuzz=0',str(observed),str(E/'observer.patch')],check=True)
        overlay=T/('observer-'+variant+'.json')
        overlay.write_text(json.dumps({'Replace':{str(base):str(observed)}})+'\n')
        binary=T/'bin'/('observed-'+variant)
        with (E/('observer-build-'+variant+'.log')).open('w') as log:
            code=run_guarded(['go','build','-p','1','-trimpath','-buildvcs=false','-overlay',str(overlay),
                             '-o',str(binary),'./benchmarks/bufferalignment'],guard,cwd=root,env=env,output=log,timeout=1200)
        assert code==0,(variant,code)
        scratch=T/'scratch'/('observe-'+variant);scratch.mkdir()
        out=E/('zero-pilot-'+variant+'.json')
        with (E/('zero-pilot-'+variant+'.stderr')).open('w') as log:
            p=subprocess.Popen([str(binary),'-out',str(out),'-observe'],cwd=root,env=dict(env,TMPDIR=str(scratch)),
                               stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True)
            try:
                for line in p.stdout:
                    assert 'checkpoint' in json.loads(line)
                    p.stdin.write('\n');p.stdin.flush()
                assert p.wait(timeout=120)==0
            except BaseException:
                p.kill();p.wait();raise
            finally:p.stdin.close();p.stdout.close()
        r=json.loads(out.read_text())
        assert r['success'] and r['cleanup'] and not r['overflow'] and not any(scratch.iterdir())
        assert all(r['final'][n]==0 for n in ['active_mappings','active_rw_bytes','active_reserved_bytes'])
        phases={}
        for phase in range(1,5):
            events=[v for v in r['large_zero_events'] if v['phase']==phase and v['bytes']>=16777216]
            assert [v['bytes'] for v in events]==([16777216,18567168] if variant=='baseline' else [16777216]),events
            if variant=='candidate':assert events[0]['dst']%2097152==0
            phases[phase]={'large_zero_events':events,'all_zero_bytes':r['totals'][str(phase)]['zero_bytes']}
        results[variant]=phases
        (E/'zero-summary.json').write_text(json.dumps({'result':'PASS','modes':results},indent=2)+'\n')
        print(variant,'expected large zero fills and cleanup PASS',flush=True)


if __name__=='__main__':main()

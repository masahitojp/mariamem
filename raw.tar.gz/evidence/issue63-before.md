## 結論と目的

**原因の同定と生成Go overlayによる小試作は完了。guestの正規実装・製品採用は未実施。**

mariamemのWASM向け移植層がbuffer pool用メモリを4KiB整列で確保する一方、wasm32のInnoDBは2MiB整列を要求する。そのため今回のfixtureでは確保・ゼロ化をやり直していた。最初から必要な整列で確保し、この初期化作業を減らす改善候補を記録する。pgmemとの速度差を埋めることを終了条件にしない。

Human（2026-11-01）: 「もう確定ならばIssueにして、次の候補を探したい」。本Issueは確認済みの原因・試作結果と残作業を固定する。新しいguest実装・main採用・リリース・版への割当をこの指示から推定しない。

## 確定した範囲

[原因のsource対応](https://github.com/masahitojp/mariamem/blob/cb67868a5bbd0252992228a72be70f2bebba7c75/benchmarks/zero-fill-cause.md)

- `guest/patches/common-portability.patch` がMariaDBの `mysys/my_largepage.c` / `my_large_virtual_alloc` に追加するWASM分岐は、`posix_memalign(&p, 4096, *size)` の直後に `memset(p, 0, *size)` を行う。
- `storage/innobase/buf/buf0buf.cc` のpool作成処理は整列後の容量不足でrelease/retryする。最初の領域はpoolとして利用される前に解放される。
- 観測した元の経路は16MiBをゼロ化→再確保して17.707MiBをゼロ化。2MiBはguestのbuffer-pool extent条件で、OS huge pageやpool容量の設定ではない。
- exact generated Goの該当確保callsite一つだけを4096→2097152へ変更した診断overlayで、各子のpool zero fillが2回→1回・16MiBとなり、返されたguestアドレスも2MiB整列となった。

## 試作結果

[全結果・再現・制限](https://github.com/masahitojp/mariamem/blob/30239a34977c6eaaa2ca804fc28e2553e498af48/benchmarks/buffer-alignment.md)

Product source_commit: `b3b3b46a8807482ad3f96725af86e031fe369b01` (v0.6.0)。tag_object_sha: `b57183b08d48884840111e8b53daa500734337f0`。
Measured harness source_commit: `d2f65eff84226006dbd1edb239decdf85e03e837`。
Apple M1 / 16GiB / macOS27.2 / Go1.27.3 / CGO0 / GOMAXPROCS8。Linux・release toolchain Go1.26.10の証拠ではない。

5組の順序交互fresh-process比較。各processで4子を順番にForkして保持。時間は各processの4子平均を5process間で中央値集計。RSSは各processのbaselineから4子保持までの増分の中央値。

| 指標 | 元の整列 | 2MiB整列 |
|---|---:|---:|
| poolのzero bytes / Fork | 33.707MiB | 16.000MiB |
| Fork中のtotal zero bytes（別の診断pilot） | 82.065MiB | 64.358MiB |
| Fork wall | 40.712ms | 38.729ms |
| Fork process CPU | 53.608ms | 52.027ms |
| 4子保持時RSS増分 | 312.203MiB | 308.859MiB |

wall/CPUは5組中4組で改善・1組で悪化。RSSは全5組で改善（2.83–3.64MiB）。非隔離Macのばらつきを含み、確実な改善率や他環境への一般化はしない。zero書込み削減量はRSS削減量と同義ではない。

正常pilot2、意図したSQL oracle失敗2、測定40子の初期データ・独立更新・cleanup PASS。全プロセスでowned scratch空・active mapping/RW/reserved bytesゼロ。分析4変異テスト、checksum・再計算、public-source check PASS。owned worktree/cache約1.2GiB削除後にも再計算PASS。

生データは専用evidence ref `evidence/buffer-alignment-20261101`、commit `f308db403eaaf3ce4d82fc274d6e13714ec41173` の `raw.tar.gz`（30,423 bytes）、SHA256 `ee51dfedeed13e008d1fd07d6eaaf6261cd1b54b1ebec680c83e69ee7192bb88`。過去のreceiptを新sourceの証拠に読み替えない。

## 将来この改善を実装する場合の残作業

- [ ] buffer poolのreserveだけに必要なalignmentを渡すguest側の最小変更を設計する。共通 `my_large_virtual_alloc` の全callerを一律2MiBへ変更しない。公開API・利用者設定の変更は想定しない。
- [ ] `my_large_virtual_alloc` のzero-filled契約を維持する。memsetの単純削除やcommitへの一律移動はしない。
- [ ] guest source patch→guest再ビルド→Go再生成で、診断overlayと同じ再試行削減が起きることを確認する。
- [ ] alignmentによるallocatorのpadding・失敗/低メモリ経路、関連する解放・cleanup、SQL/Fork分離への影響をfocusedに検査する。現在これら全体の安全性は未証明。
- [ ] 正規candidateで同じbounded比較を行い、採用を求める時点で対象platformの必要検証を決める。広範なmatrixを理由なく追加しない。効果消失・安全性未解決なら停止可能。
- [ ] 最小の製品候補をHuman Reviewへ提出する。exploratory historyの一括merge、Qualification、releaseは別判断。

## 他の調査との境界

#56 の16MiB単位memory protection試作とは別件。今回はguestのallocation alignmentであり、hostのmprotect batchingではない。次のCPU/メモリ候補探しを本Issueの終了条件に追加しない。


## 2026-11-02: 改善作業へ着手（Human承認）

HumanはSQL待ちとFork初期化の無駄削減をIssue化して進めることを承認。本件は重複Issueを作らず #63 で継続し、正常SQLの長い待ちは #68 で分離する。上の2026-11-01の記録・試作結果はそのまま保存する。

次のcheckpointでは、まずguest sourceのcaller/契約を照合し、buffer-pool reserveだけへ必要alignmentを渡す最小のsource変更案とfocused検証項目を固定する。共通allocator全体の挙動変更、zero-filled契約の緩和、過去overlayを正規guestの証拠へ読み替えることはしない。

- [x] `my_large_virtual_alloc` の宣言・定義・caller、buffer-pool extentと解放経路をpin済みsourceで照合する。
- [x] pool専用のalignment指定を最小のguest source案として記録し、他caller/非WASM経路を変えないことを示す。
- [x] 正規guest build/再生成に入る前に変更範囲・必要な検証・費用を提示する。上記checkpointの完了を製品実装や採用完了とは扱わない。

CPU費用の削減が目的であり、pgmemとの差を埋めることや性能改善率の保証は終了条件にしない。main採用・版への割当・releaseは別判断のまま。



### Source設計checkpointの結果

[3ファイルの変更案・根拠・必要検証](https://github.com/masahitojp/mariamem/blob/2cb902610b1a5b423a71a59222e5ff793d81dfd8/docs/reviews/issue63-buffer-alignment-source-plan.md) / [6ファイルのsource receipt](https://github.com/masahitojp/mariamem/blob/2cb902610b1a5b423a71a59222e5ff793d81dfd8/benchmarks/forkcompare/results/source63.json)。固定MariaDB commitの予約・解放経路を照合し、2つの採用移植patchのafter hashがv0.6.0 guest/input.jsonと一致した。

提案は `mysys/my_largepage.c` にWASM専用のalignment引数付き内部helper、`include/my_sys.h` に宣言、`buf0buf.cc` のpool reserve 1か所から既存extent定義を渡す3ファイル。旧入口は4096整列のままhelperへ委譲し、zero-filled/NULL-on-allocation-failure/size不変と既存releaseを維持する。全caller censusの完了とは主張しない。

現在は具体的なsource変更案まで。新しいguest patch、正規guest build、Go再生成、allocation failure/runtime検証は未実施で、最上部の実装・採用残作業は残る。

次の実行単位は最小experimental.patch→guest build1回→Go再生成→host build→focused SQL/分離/cleanup・確保失敗とbounded before/after比較。所要時間は未測定。過去guest build約658秒は別条件なので保証に使わず、開始時にtoolchain/diskを確認して実行予算を固定する。性能差の保証や広いmatrixの追加を終了条件にしない。

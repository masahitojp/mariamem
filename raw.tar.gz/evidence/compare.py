"""Finite local Issue63 comparison. Copy beside an owned workspace's evidence.

Run only after the bound development guest/native route succeeds. Source, data,
tool and binary hashes are retained; generated copies/caches are disposable.
"""
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import time

W = Path(__file__).resolve().parents[1]
C, T, E = W/'worktree', W/'temp', W/'evidence'
sys.path.insert(0, str(C/'scripts'))
from git_identity import require_commit
from experiment_disk import DiskGuard, run_guarded


def save(p, data):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True)+'\n')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def inventory(p):
    return {str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}


def main():
    plan = json.loads((E/'comparison-plan.json').read_text())
    for name, expected in plan['sources_sha256'].items():
        assert sha(E/name) == expected
    env = {k:v for k,v in os.environ.items() if not k.startswith(
        ('MARIAMEM_','MYSQLMEM_','GO','GODEBUG','GOMEMLIMIT','GOGC'))}
    env.update(GOTOOLCHAIN='go1.26.10', GOWORK='off', GOENV='off', CGO_ENABLED='0',
               GOMAXPROCS='8', GOCACHE=str(T/'gocache'), GOMODCACHE=str(T/'modcache'),
               GOTMPDIR=str(T/'go-tmp'), TMPDIR=str(T/'tmp'))
    for name in ['go-tmp','tmp','bin']:(T/name).mkdir(parents=True,exist_ok=True)
    guard = DiskGuard(W, min_free_gib=12, budget_gib=6)
    roots = {name:T/(name+'-product') for name in ['baseline','candidate']}
    before={}; identities={}
    for name,root in roots.items():
        commit=plan[name+'_source_commit']; require_commit(C,commit)
        if root.exists():raise AssertionError('fresh clone required: '+str(root))
        subprocess.run(['git','clone','--shared','--no-checkout',str(C),str(root)],check=True)
        subprocess.run(['git','checkout','--detach',commit],cwd=root,check=True)
        # Inspect explicitly against the clone, not the report worktree's ROOT.
        from git_identity import inspect_ref
        parsed=inspect_ref(root,'HEAD');assert parsed.object_type=='commit' and parsed.source_commit==commit
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
        identities[name]={'source_commit':commit,'object_type':parsed.object_type}
        before[name]={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts}
    differences=[p for p in sorted(set(before['baseline'])|set(before['candidate'])) if before['baseline'].get(p)!=before['candidate'].get(p)]
    go_differences=[p for p in differences if p.endswith(('.go','.s'))]
    assert go_differences and all(p.startswith('internal/generatedgo/') or p=='internal/runtimekind/kind.go' for p in go_differences),go_differences
    assert subprocess.check_output(['go','version'],env=env,text=True).strip() == 'go version go1.26.10 darwin/arm64'
    inputs = {'source_identities':identities,'baseline_guest_sha256':json.loads((roots['baseline']/'release/generated-go-inputs.json').read_text())['guest_sha256'],
              'candidate_guest_sha256':json.loads((roots['candidate']/'release/generated-go-inputs.json').read_text())['guest_sha256'],
              'plan_sha256':sha(E/'comparison-plan.json'),'source_differences':differences,'go_differences':go_differences,
              'source_inventories':before,'harness_sha256':plan['sources_sha256'],'binaries':{},
              'go':'go1.26.10 darwin/arm64','CGO_ENABLED':0,'GOMAXPROCS':8,
              'build_vcs':False,'build_vcs_reason':'Same checksum-bound untracked harness added to each clean pinned source; source identity and full inventory verified before and after. Not a release or normal host identity receipt.'}
    for mode,root in roots.items():
        target = root/'benchmarks/bufferalignmentsource'
        target.mkdir(parents=True, exist_ok=True)
        shutil.copy2(E/'measure/main.go',target/'main.go')
        shutil.copytree(E/'common',target/'common')
        binary = T/'bin'/mode
        cmd = ['go','build','-p','1','-mod=readonly','-trimpath','-buildvcs=false',
               '-o',str(binary),'./benchmarks/bufferalignmentsource']
        print('BUILD',mode,flush=True)
        with (E/('measure-build-'+mode+'.log')).open('w') as log:
            code = run_guarded(cmd,guard,cwd=root,env=env,output=log,timeout=1200)
        assert code == 0, (mode,code)
        inputs['binaries'][mode] = {'sha256':sha(binary),'command':cmd,
            'build_info':subprocess.check_output(['go','version','-m',str(binary)],env=env,text=True)}
    save(E/'measure-inputs.json',inputs)
    records=[]

    def run(variant,mode,rep,parallel=8,negative=False):
        guard.check()
        binary=T/'bin'/variant
        assert sha(binary)==inputs['binaries'][variant]['sha256']
        key=f'{mode}-p{parallel}-{rep}-{variant}'+('-negative' if negative else '')
        out=E/'results'/(key+'.json');out.parent.mkdir(exist_ok=True)
        scratch=T/'scratch'/key;scratch.mkdir(parents=True,exist_ok=True);assert not any(scratch.iterdir())
        cmd=[str(binary),'-mode',mode,'-parallel',str(parallel),'-out',str(out)]
        if negative:cmd.append('-corrupt')
        rss={}
        with (E/'results'/(key+'.stderr')).open('w') as err:
            proc=subprocess.Popen(cmd,env=dict(env,TMPDIR=str(scratch)),cwd=roots[variant],
                                  stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True)
            try:
                deadline=time.monotonic()+120
                while True:
                    assert time.monotonic()<deadline, 'child timeout '+key
                    guard.check()
                    if not select.select([proc.stdout],[],[],.1)[0]:continue
                    line=proc.stdout.readline()
                    if not line:break
                    message=json.loads(line);point=message['checkpoint']
                    value=int(subprocess.check_output(['ps','-o','rss=','-p',str(proc.pid)],text=True).strip())*1024
                    assert value>0
                    rss[point]=value
                    proc.stdin.write('\n');proc.stdin.flush()
                code=proc.wait(timeout=10)
            except BaseException:
                proc.kill();proc.wait();raise
            finally:
                proc.stdin.close();proc.stdout.close()
        result=json.loads(out.read_text())
        assert result['cleanup'] and not any(scratch.iterdir()),(key,result)
        assert result['go']=='go1.26.10' and result['gomaxprocs']==8
        if negative:
            assert code!=0 and not result['success'] and 'pristine oracle' in result['error'],result
        else:
            assert code==0 and result['success'],result
            assert result['count']==(4 if mode=='serial' else 48)
        rec={'host_loadavg':list(os.getloadavg()),'key':key,'variant':variant,'mode':mode,'rep':rep,'parallel':parallel,
             'negative':negative,'exit_code':code,'rss_bytes':rss,'result':result}
        records.append(rec)
        save(E/'observations.json',records)
        print(key,'PASS',flush=True)

    for variant in roots:run(variant,'serial','pilot-negative',negative=True)
    for mode,parallel in [('serial',8),('batch',8),('batch',4)]:
        for variant in roots:run(variant,mode,'warmup',parallel)
        for rep in range(5):
            order=['baseline','candidate'] if rep%2==0 else ['candidate','baseline']
            for variant in order:run(variant,mode,rep,parallel)
    for variant,root in roots.items():
        after={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts}
        assert all(after[n]==value for n,value in before[variant].items())
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=C,text=True).strip()
    save(E/'measure-complete.json',{'result':'PASS_MEASURED_FIELDS_ONLY',
         'records':len(records),'queue':'N/A','adoption':'already integrated; not reopened by measurement',
         'workspace':guard.check(),'scope':'post-merge measurement only; no new adoption decision'})
    print('PASS finite post-merge comparison; queue remains outside measurement scope',flush=True)


if __name__=='__main__':main()

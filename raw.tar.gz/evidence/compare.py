"""Finite local Issue63 comparison. Copy beside an owned workspace's evidence.

Run only after the bound development guest/native route succeeds. Source, data,
tool and binary hashes are retained; generated copies/caches are disposable.
"""
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import time

W = Path(__file__).resolve().parents[1]
C, T, E = W/'worktree', W/'temp', W/'evidence'
sys.path.insert(0, str(C/'scripts'))
from git_identity import require_commit
from experiment_disk import DiskGuard, run_guarded


def save(p, data):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True)+'\n')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def inventory(p):
    return {str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}


def main():
    identity = json.loads((E/'host-source.json').read_text())['source_commit']
    require_commit(C, identity)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip() == identity
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=C,text=True).strip()
    development = json.loads((T/'dev-native-rebound/development.json').read_text())
    assert development['smoke'] == 'PASS' and development['result'] == 'UNQUALIFIED'
    assert development['host_source_identity']['commit'] == identity
    plan = json.loads((E/'comparison-plan.json').read_text())
    for name, expected in plan['sources_sha256'].items():
        assert sha(E/name) == expected
    env = {k:v for k,v in os.environ.items() if not k.startswith(
        ('MARIAMEM_','MYSQLMEM_','GO','GODEBUG','GOMEMLIMIT','GOGC'))}
    env.update(GOTOOLCHAIN='go1.26.10', GOWORK='off', GOENV='off', CGO_ENABLED='0',
               GOMAXPROCS='8', GOCACHE=str(T/'gocache'), GOMODCACHE=str(T/'modcache'),
               GOTMPDIR=str(T/'go-tmp'), TMPDIR=str(T/'tmp'))
    assert subprocess.check_output(['go','version'],env=env,text=True).strip() == 'go version go1.26.10 darwin/arm64'
    guard = DiskGuard(W, min_free_gib=16, budget_gib=24)
    candidate = T/'dev-native-rebound/product'
    assert inventory(candidate) == development['host_source_inventory']
    assert sha(T/'dev-native-rebound/mariamem-dev-host') == development['binary_sha256']
    baseline = T/'baseline-product'
    shutil.copytree(candidate,baseline,ignore=shutil.ignore_patterns('generatedgo'))
    shutil.copytree(C/'internal/generatedgo',baseline/'internal/generatedgo')
    shutil.copy2(C/'internal/runtimekind/kind.go',baseline/'internal/runtimekind/kind.go')
    roots = {'baseline':baseline, 'candidate':candidate}
    before = {k:inventory(v) for k,v in roots.items()}
    differences = [n for n in sorted(set(before['baseline']) | set(before['candidate']))
                   if before['baseline'].get(n) != before['candidate'].get(n)]
    assert differences and all(n.startswith('internal/generatedgo/') or n == 'internal/runtimekind/kind.go'
                               for n in differences), differences
    inputs = {'source_commit':identity, 'baseline_runtime_source_commit':plan['baseline_source_commit'],
              'baseline_guest_sha256':json.loads((C/'release/generated-go-inputs.json').read_text())['guest_sha256'],
              'candidate_guest_sha256':development['guest_sha256'], 'plan_sha256':sha(E/'comparison-plan.json'),
              'generated_differences':differences, 'source_inventories':before,
              'harness_sha256':plan['sources_sha256'], 'binaries':{},
              'go':'go1.26.10 darwin/arm64', 'CGO_ENABLED':0, 'GOMAXPROCS':8}
    for mode,root in roots.items():
        target = root/'benchmarks/bufferalignmentsource'
        target.mkdir(parents=True, exist_ok=True)
        shutil.copy2(E/'measure/main.go',target/'main.go')
        shutil.copytree(E/'common',target/'common')
        binary = T/'bin'/mode
        binary.parent.mkdir(exist_ok=True)
        cmd = ['go','build','-p','1','-mod=readonly','-trimpath','-buildvcs=false',
               '-o',str(binary),'./benchmarks/bufferalignmentsource']
        with (E/('measure-build-'+mode+'.log')).open('w') as log:
            code = run_guarded(cmd,guard,cwd=root,env=env,output=log,timeout=1200)
        assert code == 0, (mode,code)
        inputs['binaries'][mode] = {'sha256':sha(binary),
            'build_info':subprocess.check_output(['go','version','-m',str(binary)],env=env,text=True)}
    save(E/'measure-inputs.json',inputs)
    records=[]

    def run(variant,mode,rep,parallel=8,negative=False):
        guard.check()
        binary=T/'bin'/variant
        assert sha(binary)==inputs['binaries'][variant]['sha256']
        key=f'{mode}-p{parallel}-{rep}-{variant}'+('-negative' if negative else '')
        out=E/'results'/(key+'.json');out.parent.mkdir(exist_ok=True)
        scratch=T/'scratch'/key;scratch.mkdir(parents=True,exist_ok=True);assert not any(scratch.iterdir())
        cmd=[str(binary),'-mode',mode,'-parallel',str(parallel),'-out',str(out)]
        if negative:cmd.append('-corrupt')
        rss={}
        with (E/'results'/(key+'.stderr')).open('w') as err:
            proc=subprocess.Popen(cmd,env=dict(env,TMPDIR=str(scratch)),cwd=roots[variant],
                                  stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True)
            try:
                deadline=time.monotonic()+120
                while True:
                    assert time.monotonic()<deadline, 'child timeout '+key
                    guard.check()
                    if not select.select([proc.stdout],[],[],.1)[0]:continue
                    line=proc.stdout.readline()
                    if not line:break
                    message=json.loads(line);point=message['checkpoint']
                    value=int(subprocess.check_output(['ps','-o','rss=','-p',str(proc.pid)],text=True).strip())*1024
                    assert value>0
                    rss[point]=value
                    proc.stdin.write('\n');proc.stdin.flush()
                code=proc.wait(timeout=10)
            except BaseException:
                proc.kill();proc.wait();raise
            finally:
                proc.stdin.close();proc.stdout.close()
        result=json.loads(out.read_text())
        assert result['cleanup'] and not any(scratch.iterdir()),(key,result)
        assert result['go']=='go1.26.10' and result['gomaxprocs']==8
        if negative:
            assert code!=0 and not result['success'] and 'pristine oracle' in result['error'],result
        else:
            assert code==0 and result['success'],result
            assert result['count']==(4 if mode=='serial' else 48)
        rec={'key':key,'variant':variant,'mode':mode,'rep':rep,'parallel':parallel,
             'negative':negative,'exit_code':code,'rss_bytes':rss,'result':result}
        records.append(rec)
        save(E/'observations.json',records)
        print(key,'PASS',flush=True)

    for variant in roots:run(variant,'serial','pilot-negative',negative=True)
    for mode,parallel in [('serial',8),('batch',8),('batch',4)]:
        for variant in roots:run(variant,mode,'warmup',parallel)
        for rep in range(5):
            order=['baseline','candidate'] if rep%2==0 else ['candidate','baseline']
            for variant in order:run(variant,mode,rep,parallel)
    for variant,root in roots.items():
        after=inventory(root)
        assert all(after[n]==value for n,value in before[variant].items())
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=C,text=True).strip()
    save(E/'measure-complete.json',{'result':'PASS_MEASURED_FIELDS_ONLY',
         'records':len(records),'queue':'N/A','overall_adoption':'INCONCLUSIVE',
         'workspace':guard.check()})
    print('PASS finite comparison; queue missing, overall adoption INCONCLUSIVE',flush=True)


if __name__=='__main__':main()

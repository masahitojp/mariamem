
SELECT '__dump_session__',@@time_zone,@@sql_mode,@@character_set_client,@@character_set_results,@@collation_connection,@@foreign_key_checks,@@unique_checks,@@sql_notes,@@autocommit,@@note_verbosity;

from pathlib import Path
import json,shutil
W=Path(__file__).resolve().parents[1];S=W/'temp/source';E=W/'evidence';D=S/'benchmarks/updateconditions';D.mkdir()
plan={'product_source_commit':'1862f4a89397bddfa1820d835106d3437a438cf7','parent_harness_source_commit':'549fd3ba4fdc92b407534bd2b4ce844951fbd4df','origin_guest_sha256':'6d7442204d39bc28eb4b34401874b84b4d3f517c2bb698ba7f3a465027c36cbe','objective':'Compare immediate vs COUNT-then-500ms delay and first vs second genuine UPDATE on the same child, without internal wait/notify/stack/RSS profiling. Condition intervention, not natural-tail capture or product performance acceptance.','authorization':'Human approved P8/48children, alternating three pairs, two writes per child, stop after six measured processes.','profile':{'load_at_startup':'OFF','dump_at_shutdown':'OFF','commit':1,'flush_method':'inherited O_DIRECT','other_original_args':25,'fixture_rows':1000,'route':'pipe','parallel':8,'cap':8,'gomaxprocs':8,'gogc':100},'protocol':{'pairs':3,'primary_order':[[0,500],[500,0],[0,500]],'children_per_primary':48,'primary_processes':6,'preflight':{'delay_ms':500,'parallel':8,'count':8},'wrong_seed':{'delay_ms':500,'parallel':1,'count':1},'total_protocol_processes':8,'warmups':0,'extra_repetitions':0,'update1':'UPDATE fork_probe SET v=-1 WHERE id=1','update2':'UPDATE fork_probe SET v=-2 WHERE id=1','verification':'COUNT=1000/SUM=500500 before delay; each UPDATE affects1 and SELECT matches -1 then -2; cleanup; independent prepared children.'},'measurement':'External query timers only; actual idle duration and exact query-call start age since Fork return recorded. No stack capture, timer observer goroutine, internal stage/notify hooks or parent RSS sampler. Explicit 500ms idle uses a cancelable host timer. Same binary and SQL/verification sequence across arms.','decision':{'neither_first_nor_second_tail':'STOP_NOT_REPRODUCED; no rare-tail explanation','tails_only_immediate':'Observed timing-condition association; not a proven fix or population probability','tails_in_second':'First-write-only explanation insufficient for those observed cases','tails_only_first':'Consistent with first-write/elapsed-time differences, not proof of one-time undo initialization','all_outcomes':'Report each pair, per-query p50/p95/max and >100/>500 counts, within-child second-minus-first distributions. No extra runs, no product/default change. Owner/queue attribution remains separate.'},'limitations':['The500ms pause changes both DB age and overlap with other starts/cleanup; cannot isolate age from contention.','Second UPDATE follows first UPDATE and verification; data/undo/cache state and elapsed time change together.','No-wait arm now has a second UPDATE: not an exact replay of previous single-write suite.','No internal tracing does not mean zero measurement overhead. No polling/stack observer is introduced.','Single Mac; no native, Ubuntu, adoption or release gate.'], 'budget':{'active_minutes':40,'tooling_minutes':15,'process_timeout_seconds':120,'build_timeout_seconds':1200,'disk_gib':6,'min_free_gib':12,'heavy_ci':0}}
for p in [D/'plan.json',E/'plan.json']:p.write_text(json.dumps(plan,indent=2)+'\n')
p=S/'benchmarks/forkcompare/probe/probe.go';t=p.read_text()
t=t.replace('type Sample struct {','''type Sample struct {
 DelayActualMS float64 `json:"delay_actual_ms"`
 Update2MS float64 `json:"update2_ms"`
 Check2MS float64 `json:"check2_ms"`
 FirstForkAgeMS float64 `json:"first_fork_age_ms"`
 SecondForkAgeMS float64 `json:"second_fork_age_ms"`
 Update1StartMS float64 `json:"update1_start_offset_ms"`
 Update2StartMS float64 `json:"update2_start_offset_ms"`
 Oracle1 bool `json:"oracle1"`
 Oracle2 bool `json:"oracle2"`''')
t=t.replace('type Report struct {','type Report struct {\n UpdateDelayMS int `json:"update_delay_ms"`')
t=t.replace('index int, batchStart time.Time)', 'index int, batchStart time.Time, updateDelay time.Duration)')
t=t.replace('s.ForkMS = ms(time.Since(begin))','forkReturned := time.Now()\n s.ForkMS = ms(forkReturned.Sub(begin))')
needle='\tqueryAt = time.Now()\n\tresult, e := c.ExecContext(ctx, "UPDATE fork_probe SET v=-1 WHERE id=1")';assert t.count(needle)==1
t=t.replace(needle,''' pauseAt := time.Now()
 if updateDelay > 0 {
  timer := time.NewTimer(updateDelay)
  select {
  case <-ctx.Done(): timer.Stop();return s,ctx.Err()
  case <-timer.C:
  }
 }
 s.DelayActualMS = ms(time.Since(pauseAt))
 queryAt = time.Now()
 s.FirstForkAgeMS = ms(queryAt.Sub(forkReturned))
 s.Update1StartMS = ms(queryAt.Sub(batchStart))
 result, e := c.ExecContext(ctx, "UPDATE fork_probe SET v=-1 WHERE id=1")''')
needle='\ts.Oracle = true\n\treturn s, nil';assert t.count(needle)==1
t=t.replace(needle,''' s.Oracle1 = true
 queryAt = time.Now()
 s.SecondForkAgeMS = ms(queryAt.Sub(forkReturned))
 s.Update2StartMS = ms(queryAt.Sub(batchStart))
 result, e = c.ExecContext(ctx,"UPDATE fork_probe SET v=-2 WHERE id=1")
 s.Update2MS = ms(time.Since(queryAt))
 if e != nil {return s,e}
 n,e = result.RowsAffected()
 if e != nil || n != 1 {return s,fmt.Errorf("second mutation affected=%d: %v",n,e)}
 queryAt = time.Now()
 e = c.QueryRowContext(ctx,"SELECT v FROM fork_probe WHERE id=1").Scan(&value)
 s.Check2MS = ms(time.Since(queryAt))
 if e != nil {return s,e}
 if value != -2 {return s,fmt.Errorf("second mutation value=%d",value)}
 s.Oracle2 = true
 s.Oracle = s.Oracle1 && s.Oracle2
 return s,nil''')
t=t.replace('one(ctx, sn, r.Route, index, at)','one(ctx, sn, r.Route, index, at, time.Duration(r.UpdateDelayMS)*time.Millisecond)')
t=t.replace('\tflag.Parse()', '\tflag.IntVar(&r.UpdateDelayMS,"update-delay-ms",0,"experiment:0 or500 ms after pristine COUNT")\n\tflag.Parse()')
t=t.replace('if *out == "" ||', 'if (r.UpdateDelayMS != 0 && r.UpdateDelayMS != 500) || *out == "" ||')
# No hidden profile/parent handshake is used; execution controller strips all observer env.
p.write_text(t)
p=S/'benchmarks/forkcompare/maria/main.go';t=p.read_text();a=t.index('\t\t\t\tctx = timing.WithRecorder(');b=t.index('\n\t\t\t\tc, e := s.Fork(ctx)',a);t=t[:a]+t[b:]
for line in ['\t"encoding/json"\n','\t"github.com/masahitojp/mariamem/internal/timing"\n','\t"os"\n','\t"path/filepath"\n']:t=t.replace(line,'')
p.write_text(t)
# Only the fixed argument selector overlays generated code; no forkstages overlay.
t=(S/'benchmarks/bufferflush/overlay.py').read_text();a=t.index("s,o=map(");b=t.index("\np=s/",a)
t=t[:a]+"s,o=map(lambda p:Path(p).resolve(),sys.argv[1:]);o.mkdir(parents=True,exist_ok=True);maps={'Replace':{}};hashes=[]"+t[b:]
(D/'overlay.py').write_text(t)
# Existing identity/disk-bounded build recipe, adjusted only to the selected overlay.
t=(W.parents[0]/'buffer-flush-settings/evidence/build.py').read_text().replace("'benchmarks/bufferflush/'))", "'benchmarks/bufferflush/','benchmarks/updateconditions/'))").replace("s/'benchmarks/bufferflush/overlay.py'","s/'benchmarks/updateconditions/overlay.py'")
(E/'build.py').write_text(t)

from pathlib import Path
import os,sys,json,subprocess,hashlib,platform,time
W=Path(__file__).resolve().parents[1];T=W/'temp';S=T/'source';E=W/'evidence';sys.path.insert(0,str(S/'scripts'))
from git_identity import require_commit
from experiment_disk import DiskGuard,run_guarded
save=lambda n,d:(E/n).write_text(json.dumps(d,indent=2)+'\n')
i=json.loads((E/'inputs.json').read_text());require_commit(S,i['harness_source_commit']);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==i['harness_source_commit'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True);assert hashlib.sha256((T/'probe').read_bytes()).hexdigest()==i['binary_sha256']
assert {x['path'] for x in i['overlay']}=={'internal/generatedgo/code/p5/p5_pure.go','internal/generatedgo/code/base/buffer_load.go','internal/generatedgo/code/base/buffer_load_test.go'}
assert not(E/'records.json').exists(),'Do not resume or repeat a started matrix'
env={k:v for k,v in os.environ.items() if not k.startswith(('MARIAMEM_','MYSQLMEM_','GODEBUG','GOGC','GOMEMLIMIT','GOFLAGS','DEFAULT_SETTINGS_','UPDATE_WAIT_','UPDATE_NOTIFY_','FORKSTAGES_','ISSUE116_'))}
env.update(GOMAXPROCS='8',GOGC='100',DEFAULT_SETTINGS_VARIANT='both-off',GOTOOLCHAIN='local')
save('host.json',{'platform':platform.platform(),'cpu':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'memory_bytes':int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),'logical_cpus':int(subprocess.check_output(['sysctl','-n','hw.ncpu'],text=True)),'observer_variables_present':[k for k in env if k.startswith(('MARIAMEM_TIMING','MARIAMEM_GUEST_TIMING','UPDATE_WAIT_','UPDATE_NOTIFY_','FORKSTAGES_'))]})
guard=DiskGuard(W,12,6);records=[]
def run(name,delay,p,count,pair=None,negative=False,preflight=False):
 scratch=T/name;scratch.mkdir();v=dict(env,TMPDIR=str(scratch))
 if preflight:v['DEFAULT_SETTINGS_PREFLIGHT']='1'
 out=E/(name+'.json');cmd=[str(T/'probe'),'-route','pipe','-parallel',str(p),'-count',str(count),'-update-delay-ms',str(delay),'-out',str(out)]+(['-corrupt-seed'] if negative else [])
 start=time.monotonic()
 with (E/(name+'.log')).open('w') as log:code=run_guarded(cmd,guard,cwd=S/'benchmarks/forkcompare',env=v,output=log,timeout=120)
 d=json.loads(out.read_text());assert d['cleanup_complete'] and d['root_closed_before_forks'] and not any(scratch.iterdir());assert d['route']=='pipe' and d['parallel']==p and d['gomaxprocs']==8 and d['update_delay_ms']==delay
 if negative:
  assert code!=0 and not d['success'] and 'pristine oracle' in d['error']
  assert all(not x['oracle1'] and not x['oracle2'] and x['delay_actual_ms']==0 and x['first_fork_age_ms']==0 and x['second_fork_age_ms']==0 for x in d['samples'])
 else:
  assert code==0 and d['success'] and len(d['samples'])==count and {x['index'] for x in d['samples']}==set(range(count))
  for x in d['samples']:
   assert x['oracle'] and x['oracle1'] and x['oracle2'] and x['cleanup_complete']
   assert x['delay_actual_ms']>=delay-0.01 and x['first_fork_age_ms']>=x['delay_actual_ms']
   assert x['second_fork_age_ms']>=x['first_fork_age_ms']+x['update_ms']+x['check_ms']-0.01
   assert abs(x['offset_ms']+x['fork_ms']+x['first_fork_age_ms']-x['update1_start_offset_ms'])<0.01
   assert abs(x['offset_ms']+x['fork_ms']+x['second_fork_age_ms']-x['update2_start_offset_ms'])<0.01
   assert sum(x[k] for k in ['count_ms','delay_actual_ms','update_ms','check_ms','update2_ms','check2_ms'])<=x['sql_ms']+0.01
 if preflight:
  configs=[d['config']]+[x['config'] for x in d['samples']]
  expected={'innodb_buffer_pool_load_at_startup':'OFF','innodb_buffer_pool_dump_at_shutdown':'OFF','innodb_flush_log_at_trx_commit':'1','innodb_flush_method':'O_DIRECT','innodb_buffer_pool_size':'16777216','innodb_log_buffer_size':'2097152','innodb_read_io_threads':'1','innodb_write_io_threads':'2','innodb_purge_threads':'1','innodb_use_native_aio':'OFF'}
  for c in configs:assert all(c[k]==val for k,val in expected.items()),c
 else:assert not d.get('config') and all(not x.get('config') for x in d['samples'])
 rec={'name':name,'delay_ms':delay,'parallel':p,'count':count,'pair':pair,'negative':negative,'preflight':preflight,'report':out.name,'exit_code':code,'process_wall_ms':(time.monotonic()-start)*1000,'binary_sha256':i['binary_sha256'],'update1_over100':sum(x['update_ms']>100 for x in d['samples']),'update2_over100':sum(x['update2_ms']>100 for x in d['samples'])}
 records.append(rec);save('records.json',records);print(name,'PASS',rec['update1_over100'],rec['update2_over100'],'tails',flush=True)
run('effective',500,8,8,preflight=True)
run('wrong-seed',500,1,1,negative=True)
for pair,order in enumerate([[0,500],[500,0],[0,500]]):
 for delay in order:run(f'pair{pair}-delay{delay}',delay,8,48,pair=pair)
save('complete.json',{'result':'COLLECTED','primary_processes':6,'controls':2,'natural_repeats':0,'primary_children':288,'primary_updates':576,'harness_source_commit':i['harness_source_commit'],'controller_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'peak_workspace_bytes':guard.peak,'min_free_bytes':guard.minimum_free})

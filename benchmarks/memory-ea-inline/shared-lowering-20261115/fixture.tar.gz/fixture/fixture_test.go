package fixture
import("testing";"bytes";"sync/atomic";"encoding/binary";base "github.com/masahitojp/mariamem/internal/generatedgo/code/base")
func TestDifferential(t *testing.T){cases:=0;for _,bound:=range []uint64{0,1,3,4,6,7,8,15,16}{for _,addr:=range []int32{-1,0,1,3,4,7,8,12,13,15,16}{for mode:=int32(0);mode<5;mode++{var values [2]uint64;var traps [2]any;var memories [2][]byte
for i,f:=range []func(*base.Module,int32,int32)uint64{Original,Candidate}{m:=&base.Module{Memory:make([]byte,16),MemSize:new(atomic.Uint64)};m.MemSize.Store(bound);func(){defer func(){traps[i]=recover()}();values[i]=f(m,addr,mode)}();memories[i]=m.Memory}
if values[0]!=values[1]||traps[0]!=traps[1]||!bytes.Equal(memories[0],memories[1]){t.Fatalf("b%d a%d mode%d value%v trap%v",bound,addr,mode,values,traps)}
if mode==1&&bound>=4&&bound<8{if traps[1]!="wasm: memory access out of bounds"||binary.LittleEndian.Uint32(memories[1])!=123||binary.LittleEndian.Uint32(memories[1][4:])!=0{t.Fatal("partial store ordering")}}
if mode==2&&bound>=4&&traps[1]!=nil{t.Fatal("grow not observed")};if mode==3&&traps[1]==nil{t.Fatal("nonwrap")};cases++}}};t.Log("cases",cases)}

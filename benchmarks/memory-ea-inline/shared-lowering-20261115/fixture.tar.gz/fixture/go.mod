module github.com/masahitojp/mariamem/spikefixture

go 1.26.0
require github.com/masahitojp/mariamem v0.0.0
replace github.com/masahitojp/mariamem => <PRODUCT_WORKTREE>

package fixture

import (
	base "github.com/masahitojp/mariamem/internal/generatedgo/code/base"
	"unsafe"
)

func Candidate(m *base.Module, a int32, mode int32) uint64 {
	{
		ptr := unsafe.Pointer(unsafe.SliceData(m.Memory))
		var v uint32
		if mode == 1 {
			{
				mariamemEA := uint64(0) + 0
				if mariamemEA+4 >
					m.MemSize.Load() {
					goto mariamemBoundsTrap
				}

				*(*uint32)(unsafe.Add(ptr, uint64(mariamemEA))) = uint32(123)
			}
			{
				mariamemEA := uint64(4) + 0
				if mariamemEA+4 >
					m.MemSize.Load() {
					goto mariamemBoundsTrap
				}

				*(*uint32)(unsafe.Add(ptr, uint64(mariamemEA))) = uint32(456)
			}
			return 1
		}
		if mode == 2 {
			{
				mariamemEA := uint64(0) + 0
				if mariamemEA+4 >
					m.MemSize.Load() {
					goto mariamemBoundsTrap
				}

				*(*uint32)(unsafe.Add(ptr, uint64(mariamemEA))) = uint32(123)
			}
			m.MemSize.Store(8)
			{
				mariamemEA := uint64(4) + 0
				if mariamemEA+4 >
					m.MemSize.Load() {
					goto mariamemBoundsTrap
				}

				v = *(*uint32)(unsafe.Add(ptr, uint64(mariamemEA)))
			}
			return uint64(v)
		}
		if mode == 3 {
			{
				mariamemEA := uint64(uint64(uint32(a))) + 4294967295
				if mariamemEA+4 >
					m.MemSize.Load() {
					goto mariamemBoundsTrap
				}

				v = *(*uint32)(unsafe.Add(ptr, uint64(mariamemEA)))
			}
			return uint64(v)
		}
		if mode == 4 {
			{
				mariamemEA := uint64(uint64(uint32(a))) + 0
				if mariamemEA+4 >
					m.MemSize.Load() {
					goto mariamemBoundsTrap
				}

				_ = *(*uint32)(unsafe.Add(ptr, uint64(mariamemEA)))
			}
			return 0
		}
		{
			mariamemEA := uint64(uint64(uint32(a))) + 0
			if mariamemEA+4 >
				m.MemSize.Load() {
				goto mariamemBoundsTrap
			}

			*(*uint32)(unsafe.Add(ptr, uint64(mariamemEA))) = uint32(987)
		}
		{
			mariamemEA := uint64(uint64(uint32(a))) + 0
			if mariamemEA+4 >
				m.MemSize.Load() {
				goto mariamemBoundsTrap
			}

			v = *(*uint32)(unsafe.Add(ptr, uint64(mariamemEA)))
		}
		return uint64(v)
	}
mariamemBoundsTrap:
	panic("wasm: memory access out of bounds")
}

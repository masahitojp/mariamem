package fixture
import("unsafe";base "github.com/masahitojp/mariamem/internal/generatedgo/code/base")
func Original(m *base.Module,a int32,mode int32)uint64{
 ptr:=unsafe.Pointer(unsafe.SliceData(m.Memory))
 var v uint32
 if mode==1 {
 *(*uint32)(unsafe.Add(ptr,base.MemoryEA(m,0,0,4)))=uint32(123)
 *(*uint32)(unsafe.Add(ptr,base.MemoryEA(m,4,0,4)))=uint32(456)
 return 1
 }
 if mode==2 {
 *(*uint32)(unsafe.Add(ptr,base.MemoryEA(m,0,0,4)))=uint32(123)
 m.MemSize.Store(8)
 v=*(*uint32)(unsafe.Add(ptr,base.MemoryEA(m,4,0,4)))
 return uint64(v)
 }
 if mode==3 {
 v=*(*uint32)(unsafe.Add(ptr,base.MemoryEA(m,uint64(uint32(a)),4294967295,4)))
 return uint64(v)
 }
 if mode==4 {
 _=*(*uint32)(unsafe.Add(ptr,base.MemoryEA(m,uint64(uint32(a)),0,4)))
 return 0
 }
 *(*uint32)(unsafe.Add(ptr,base.MemoryEA(m,uint64(uint32(a)),0,4)))=uint32(987)
 v=*(*uint32)(unsafe.Add(ptr,base.MemoryEA(m,uint64(uint32(a)),0,4)))
 return uint64(v)
}

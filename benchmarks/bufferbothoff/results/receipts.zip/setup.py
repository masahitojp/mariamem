from pathlib import Path
import json,shutil
W=Path(__file__).resolve().parents[1];S=W/'temp/source';E=W/'evidence';D=S/'benchmarks/bufferbothoff';D.mkdir()
old=S/'benchmarks/bufferloadoff'
s=(old/'argv.go.txt').read_text();s=s[:s.index('// Reserve')]+'''// Two explicit options use a private256-byte frame, including copied argv.
// Original argv and caller timing slots are never overwritten.
func BufLoadArg(m *Module, argv int32) (int32, int32, func()) {
 if loadVariant != "load-off" && loadVariant != "both-off" { panic("invalid load/dump variant") }
 if m.G0 != argv || argv < 256 { panic("unexpected argv/stack relation") }
 for i,arg := range expectedLoadArgs {
  ea:=MemoryEA(m,uint64(uint32(argv)),uint64(i*4),4)
  p:=binary.LittleEndian.Uint32(m.Memory[ea:ea+4]); var b []byte
  for j:=uint64(0);j<512;j++ {v:=m.Memory[MemoryEA(m,uint64(p),j,1)];if v==0 {break};b=append(b,v)}
  if string(b)!=arg {panic(fmt.Sprintf("argv[%d] preimage mismatch",i))}
 }
 ea:=MemoryEA(m,uint64(uint32(argv)),0,104)
 if binary.LittleEndian.Uint32(m.Memory[ea+100:ea+104])!=0 {panic("missing argv terminator")}
 prior:=m.G0; addr:=prior-256;at:=MemoryEA(m,uint64(uint32(addr)),0,256)
 var saved [256]byte;copy(saved[:],m.Memory[at:at+256])
 options:=[]string{"--innodb-buffer-pool-load-at-startup=0","--innodb-buffer-pool-dump-at-shutdown=1"}
 if loadVariant=="both-off" {options[1]="--innodb-buffer-pool-dump-at-shutdown=0"}
 copy(m.Memory[at:at+100],m.Memory[ea:ea+100])
 offset:=uint64(128)
 for i,opt:=range options {
  copy(m.Memory[at+offset:],append([]byte(opt),0))
  binary.LittleEndian.PutUint32(m.Memory[at+100+uint64(i*4):],uint32(addr)+uint32(offset))
  offset+=uint64(len(opt)+1)
 }
 binary.LittleEndian.PutUint32(m.Memory[at+108:],0);m.G0=addr
 return 27,addr,func(){m.G0=prior;copy(m.Memory[at:at+256],saved[:])}
}
''';(D/'argv.go.txt').write_text(s)
s=(old/'overlay.py').read_text().replace('benchmarks/bufferloadoff','benchmarks/bufferbothoff').replace("'benchmarks/bufferloadoff'","'benchmarks/bufferbothoff'").replace('loadArgc, restoreLoadStack := base.BufLoadArg(m,v8)','loadArgc, loadArgv, restoreLoadStack := base.BufLoadArg(m,v8)').replace('Fn5739(m, loadArgc, v8)','Fn5739(m, loadArgc, loadArgv)');(D/'overlay.py').write_text(s)
s=(old/'argv-test.go.txt').read_text();s=s[:s.index('func TestBufferLoadSelector')]+'''func TestBufferLoadSelector(t *testing.T) {
 old:=loadVariant;defer func(){loadVariant=old}()
 fixture:=func()*Module {
  b:=bytes.Repeat([]byte{0xa5},16384)
  for i,arg:=range expectedLoadArgs {ptr:=4096+i*256;copy(b[ptr:],append([]byte(arg),0));binary.LittleEndian.PutUint32(b[512+i*4:],uint32(ptr))}
  binary.LittleEndian.PutUint32(b[612:],0)
  m:=&Module{Memory:b,G0:512,MemSize:new(atomic.Uint64)};m.MemSize.Store(uint64(len(b)));return m
 }
 for _,mode:=range []string{"load-off","both-off"} {
  loadVariant=mode;m:=fixture();before:=bytes.Clone(m.Memory)
  n,argv,release:=BufLoadArg(m,512)
  if n!=27||argv!=256||m.G0!=256 {t.Fatal("argc/stack")}
  if !bytes.Equal(before[:256],m.Memory[:256])||!bytes.Equal(before[512:],m.Memory[512:]) {t.Fatal("outside scratch modified")}
  if !bytes.Equal(before[512:612],m.Memory[256:356]) {t.Fatal("original argv not retained")}
  want:=[]string{"--innodb-buffer-pool-load-at-startup=0","--innodb-buffer-pool-dump-at-shutdown=1"}
  if mode=="both-off" {want[1]="--innodb-buffer-pool-dump-at-shutdown=0"}
  for i,v:=range want {p:=binary.LittleEndian.Uint32(m.Memory[356+i*4:]);if p<384||int(p)+len(v)+1>512 {t.Fatal("option overlap")};if string(m.Memory[p:p+uint32(len(v)+1)])!=v+"\\x00" {t.Fatal("option")}}
  if binary.LittleEndian.Uint32(m.Memory[364:368])!=0 {t.Fatal("terminator")}
  release();if m.G0!=512||!bytes.Equal(before,m.Memory) {t.Fatal("restoration")}
 }
 for _,kind:=range []string{"mode","stack","underflow","preimage","terminator","bounds"} {
  m:=fixture();loadVariant="load-off"
  switch kind {case "mode":loadVariant="invalid";case "stack":m.G0=100;case "underflow":m.G0=128;case "preimage":m.Memory[4096]='X';case "terminator":m.Memory[612]=1;case "bounds":m.MemSize.Store(600)}
  before:=bytes.Clone(m.Memory);prior:=m.G0
  func(){defer func(){if recover()==nil {t.Fatal("invalid accepted",kind)}}();BufLoadArg(m,512)}()
  if m.G0!=prior||!bytes.Equal(before,m.Memory) {t.Fatal("invalid mutated memory",kind)}
 }
}
''';(D/'argv-test.go.txt').write_text(s)
# Split cleanup spans only in benchmark harness, preserving operation order.
p=S/'benchmarks/forkcompare/probe/probe.go';s=p.read_text();s=s.replace('type Sample struct {','type Sample struct {\n RetireMS float64 `json:"retire_ms"`\n WaitMS float64 `json:"wait_ms"`\n CloseMS float64 `json:"close_ms"`')
s=s.replace('func retire(d *Database, p *sql.DB, c *sql.Conn) error {','func retire(d *Database, p *sql.DB, c *sql.Conn) error { return retireMeasured(d,p,c,nil) }\nfunc retireMeasured(d *Database, p *sql.DB, c *sql.Conn, sample *Sample) error {\n at:=time.Now()')
s=s.replace('\tif d != nil {\n\t\tctx, cancel := context.WithTimeout', '\tif sample!=nil {sample.RetireMS=ms(time.Since(at))}\n\tif d != nil {\n\t\tctx, cancel := context.WithTimeout')
s=s.replace('\t\tif d.Wait != nil {','\t\tat=time.Now()\n\t\tif d.Wait != nil {').replace('\t\te = errors.Join(e, d.Close())','\t\tif sample!=nil {sample.WaitMS=ms(time.Since(at))}\n\t\tat=time.Now()\n\t\te = errors.Join(e, d.Close())\n\t\tif sample!=nil {sample.CloseMS=ms(time.Since(at))}')
s=s.replace('cleanupErr := retire(d, p, c)','cleanupErr := retireMeasured(d, p, c, &s)');p.write_text(s)
# Source-bound predeclared finite protocol.
plan={'product_source_commit':'1862f4a89397bddfa1820d835106d3437a438cf7','parent_harness_source_commit':'5472e3df7fbee38973f030e61c0e9dd293b735bd','origin_guest_sha256':'6d7442204d39bc28eb4b34401874b84b4d3f517c2bb698ba7f3a465027c36cbe','authorization':'Human: compare load-only OFF against both OFF; do not run dump-only OFF.','variants':{'load-off':{'load':0,'dump':1},'both-off':{'load':0,'dump':0}},'parallel':[4,8],'count':48,'pairs':5,'warmup_per_cell':1,'preflight':'root +8 children/arm effective settings, separate wrong-seed rejection/arm','measurement':'same binary all processes; ordinary Pipe, no trace/profile; COUNT/UPDATE/check, Fork, retire/WaitDisconnected/Close and batch CPU/wall/RSS','decision':'No adoption. Compare median paired Close/cleanup/batch/CPU/Fork and all tail counts. A bounded benefit requires >=5% median paired batch or Close reduction at both P, >=4/5 winning pairs for that metric at both P, no >5% paired Fork/CPU/batch regression and no new >100ms SQL tail; otherwise stop as inconclusive/tradeoff. No extra repeats.','budget':{'active_minutes':45,'tooling_minutes':15,'heavy_ci':0,'disk_gib':6,'min_free_gib':12,'process_timeout_seconds':120,'build_timeout_seconds':1200}}
(E/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
oldE=W.parent/'buffer-load-repeat/evidence'
for n in ['build.py','run.py','analyze.py','overlap.py']:shutil.copy2(oldE/n,E/n)
p=E/'build.py';s=p.read_text().replace("'benchmarks/bufferloadoff/'","'benchmarks/bufferloadoff/','benchmarks/bufferbothoff/'").replace('benchmarks/bufferloadoff/overlay.py','benchmarks/bufferbothoff/overlay.py');p.write_text(s)
p=E/'run.py';s=p.read_text().replace("['current','load-off']","['load-off','both-off']").replace("['load-off','current']","['both-off','load-off']");s=s.replace("('ON' if variant=='current' else 'OFF')","'OFF'");s=s.replace("assert d['config']['innodb_buffer_pool_load_at_startup']=='OFF'","assert d['config']['innodb_buffer_pool_load_at_startup']=='OFF'\n  assert all(c['innodb_buffer_pool_dump_at_shutdown']==('ON' if variant=='load-off' else 'OFF') for c in configs)")
s=s.replace("'ISSUE116_'))","'ISSUE116_','UPDATE_WAIT_'))")
s=s.replace("'count_ms','update_ms','check_ms'","'count_ms','update_ms','check_ms','retire_ms','wait_ms','close_ms'")
s=s.replace("if preflight:\n  configs", "assert all(v['retire_ms']+v['wait_ms']+v['close_ms']<=v['cleanup_ms']+.02 for v in d['samples'])\n if preflight:\n  configs")
s=s.replace("save('preflight.json'", "a=json.loads((e/'effective-load-off.json').read_text());b=json.loads((e/'effective-both-off.json').read_text())\nfor aa,bb in zip([a['root']]+a['children'],[b['root']]+b['children']):\n assert {k:(aa[k],bb[k]) for k in aa if aa[k]!=bb[k]}=={'innodb_buffer_pool_dump_at_shutdown':('ON','OFF')}\nsave('preflight.json'")
p.write_text(s)

from pathlib import Path
import json,shutil
W=Path(__file__).resolve().parents[1];S=W/'temp/source';E=W/'evidence';D=S/'benchmarks/bufferflush';D.mkdir();old=S/'benchmarks/bufferbothoff'
s=(old/'argv.go.txt').read_text();s=s[:s.index('// Two explicit')]+'''// Experiment-only selector. All original25 arguments are copied, followed by
// explicit options in a private512-byte frame; restore the entire scratch frame.
func flushOptions() []string {
 if loadVariant!="both-off" && loadVariant!="commit0" && loadVariant!="commit0-method" && loadVariant!="invalid-method" {panic("invalid flush variant")}
 c:="1";if loadVariant!="both-off" {c="0"}
 options:=[]string{"--innodb-buffer-pool-load-at-startup=0","--innodb-buffer-pool-dump-at-shutdown=0","--innodb-flush-log-at-trx-commit="+c}
 if loadVariant=="commit0-method" {options=append(options,"--innodb-flush-method=O_DIRECT_NO_FSYNC")}
 if loadVariant=="invalid-method" {options=append(options,"--innodb-flush-method=O_DIRECT_NOSYNC")}
 return options
}
func BufLoadArg(m *Module, argv int32) (int32,int32,func()) {
 options:=flushOptions()
 if m.G0!=argv || argv<512 {panic("unexpected argv/stack relation")}
 for i,arg:=range expectedLoadArgs {
  ea:=MemoryEA(m,uint64(uint32(argv)),uint64(i*4),4);p:=binary.LittleEndian.Uint32(m.Memory[ea:ea+4]);var b []byte
  for j:=uint64(0);j<512;j++ {v:=m.Memory[MemoryEA(m,uint64(p),j,1)];if v==0 {break};b=append(b,v)}
  if string(b)!=arg {panic(fmt.Sprintf("argv[%d] preimage mismatch",i))}
 }
 ea:=MemoryEA(m,uint64(uint32(argv)),0,104)
 if binary.LittleEndian.Uint32(m.Memory[ea+100:ea+104])!=0 {panic("missing argv terminator")}
 prior:=m.G0;addr:=prior-512;at:=MemoryEA(m,uint64(uint32(addr)),0,512)
 var saved [512]byte;copy(saved[:],m.Memory[at:at+512]);copy(m.Memory[at:at+100],m.Memory[ea:ea+100])
 offset:=uint64(256)
 for i,opt:=range options {copy(m.Memory[at+offset:],append([]byte(opt),0));binary.LittleEndian.PutUint32(m.Memory[at+100+uint64(i*4):],uint32(addr)+uint32(offset));offset+=uint64(len(opt)+1)}
 binary.LittleEndian.PutUint32(m.Memory[at+100+uint64(len(options)*4):],0);m.G0=addr
 return int32(25+len(options)),addr,func(){m.G0=prior;copy(m.Memory[at:at+512],saved[:])}
}
''';(D/'argv.go.txt').write_text(s)
s=(old/'overlay.py').read_text().replace('benchmarks/bufferbothoff','benchmarks/bufferflush');(D/'overlay.py').write_text(s)
s=(old/'argv-test.go.txt').read_text();s=s[:s.index('func TestBufferLoadSelector')]+'''func TestBufferLoadSelector(t *testing.T) {
 old:=loadVariant;defer func(){loadVariant=old}()
 fixture:=func()*Module {
  b:=bytes.Repeat([]byte{0xa5},16384)
  for i,arg:=range expectedLoadArgs {ptr:=4096+i*256;copy(b[ptr:],append([]byte(arg),0));binary.LittleEndian.PutUint32(b[1024+i*4:],uint32(ptr))};binary.LittleEndian.PutUint32(b[1124:],0)
  m:=&Module{Memory:b,G0:1024,MemSize:new(atomic.Uint64)};m.MemSize.Store(uint64(len(b)));return m
 }
 for _,mode:=range []string{"both-off","commit0","commit0-method","invalid-method"} {
  loadVariant=mode;m:=fixture();before:=bytes.Clone(m.Memory);n,argv,release:=BufLoadArg(m,1024)
  c:="1";if mode!="both-off" {c="0"};want:=[]string{"--innodb-buffer-pool-load-at-startup=0","--innodb-buffer-pool-dump-at-shutdown=0","--innodb-flush-log-at-trx-commit="+c}
  if mode=="commit0-method" {want=append(want,"--innodb-flush-method=O_DIRECT_NO_FSYNC")};if mode=="invalid-method" {want=append(want,"--innodb-flush-method=O_DIRECT_NOSYNC")}
  if int(n)!=25+len(want)||argv!=512||m.G0!=512 {t.Fatal("argc/stack")}
  if !bytes.Equal(before[:512],m.Memory[:512])||!bytes.Equal(before[1024:],m.Memory[1024:]) {t.Fatal("outside scratch modified")}
  if !bytes.Equal(before[1024:1124],m.Memory[512:612]) {t.Fatal("original argv not retained")}
  for i,v:=range want {p:=binary.LittleEndian.Uint32(m.Memory[612+i*4:]);if p<768||int(p)+len(v)+1>1024 {t.Fatal("option overlap")};if string(m.Memory[p:p+uint32(len(v)+1)])!=v+"\\x00" {t.Fatal("option")}}
  if binary.LittleEndian.Uint32(m.Memory[612+len(want)*4:])!=0 {t.Fatal("terminator")};release();if m.G0!=1024||!bytes.Equal(before,m.Memory) {t.Fatal("restoration")}
 }
 for _,kind:=range []string{"mode","stack","preimage","terminator","bounds"} {
  m:=fixture();loadVariant="both-off";switch kind {case "mode":loadVariant="invalid";case "stack":m.G0=100;case "preimage":m.Memory[4096]='X';case "terminator":m.Memory[1124]=1;case "bounds":m.MemSize.Store(1100)}
  before:=bytes.Clone(m.Memory);prior:=m.G0
  func(){defer func(){if recover()==nil {t.Fatal("invalid accepted",kind)}}();BufLoadArg(m,1024)}();if m.G0!=prior||!bytes.Equal(before,m.Memory) {t.Fatal("invalid mutated",kind)}
 }
}
''';(D/'argv-test.go.txt').write_text(s)
p=S/'benchmarks/forkcompare/probe/probe.go';s=p.read_text().replace("'innodb_flush_sync'","'innodb_flush_method','innodb_data_file_buffering','innodb_log_file_buffering','innodb_data_file_write_through','innodb_log_file_write_through','innodb_flush_sync'");p.write_text(s)
plan={'product_source_commit':'1862f4a89397bddfa1820d835106d3437a438cf7','parent_harness_source_commit':'eaeb1e988bd2a087a10e6cd083fce5d5a358ac4f','origin_guest_sha256':'6d7442204d39bc28eb4b34401874b84b4d3f517c2bb698ba7f3a465027c36cbe','authorization':'Human requested additional commit/flush sampling; fixed bounded three-arm comparison, no adoption.','variants':{'both-off':{'load':0,'dump':0,'commit':1,'method':'inherited'},'commit0':{'load':0,'dump':0,'commit':0,'method':'inherited'},'commit0-method':{'load':0,'dump':0,'commit':0,'method':'O_DIRECT_NO_FSYNC'}},'literal_negative':'One startup attempt O_DIRECT_NOSYNC, record rejection rather than silently relabel; corrected spelling explicitly separate.','parallel':[4,8],'count':48,'primary_blocks':5,'order':'Rotate P; rotate three-arm order by block/P and reverse alternate blocks.','processes':{'primary':30,'warmups':6,'effective_preflights':3,'wrong_seed':3,'literal_invalid':1},'metrics':['COUNT/UPDATE/check distributions and >100/>500 counts','batch CPU/wall','Fork','retire/WaitDisconnected/Close','20ms RSS'],'decision':'Descriptive bounded sampling, no statistical/population or adoption claim. For each contrast and P report all blocked paired effects/wins. Benefit signal requires >=5% median blocked batch or UPDATE-p50 reduction at both P, >=4/5 wins in that same metric at both P, no >5% median Fork/CPU/batch regression. Tails retained separately; reduced observed tails do not prove cure. No extra repeats.','limits':'Single Mac12.3.3 memory VFS; not Testcontainers10.11 or durability/crash proof; UNQUALIFIED argv overlay.','budget':{'disk_gib':6,'min_free_gib':12,'active_minutes':45,'tooling_minutes':15,'heavy_ci':0,'process_timeout_seconds':120,'build_timeout_seconds':1200}}
for p in [E/'plan.json',D/'plan.json']:p.write_text(json.dumps(plan,indent=2)+'\n')
oldE=W.parent/'buffer-both-off/evidence'
for n in ['build.py','run.py']:shutil.copy2(oldE/n,E/n)
p=E/'build.py';s=p.read_text().replace("'benchmarks/bufferbothoff/'","'benchmarks/bufferbothoff/','benchmarks/bufferflush/'").replace('benchmarks/bufferbothoff/overlay.py','benchmarks/bufferflush/overlay.py');p.write_text(s)
p=E/'run.py';s=p.read_text();s=s[:s.index("for v in ['load-off','both-off']:run")]
s=s.replace("assert all(c['innodb_buffer_pool_dump_at_shutdown']==('ON' if variant=='load-off' else 'OFF') for c in configs)","assert all(c['innodb_buffer_pool_dump_at_shutdown']=='OFF' and c['innodb_flush_log_at_trx_commit']==('1' if variant=='both-off' else '0') for c in configs)\n  for c in configs:\n   assert all(k in c for k in ['innodb_flush_method','innodb_data_file_buffering','innodb_log_file_buffering','innodb_data_file_write_through','innodb_log_file_write_through'])\n   if variant=='commit0-method':assert c['innodb_flush_method'] in ['O_DIRECT_NO_FSYNC','O_DIRECT']")
s+='''# Literal supplied spelling: startup rejection is evidence, not a timed arm.
negout=e/'literal-invalid.json';neglog=e/'literal-invalid.log';negv=dict(env,DEFAULT_SETTINGS_VARIANT='invalid-method',TMPDIR=str(t/'scratch'))
with neglog.open('w') as log:
 r=subprocess.run([str(t/'probe'),'-out',str(negout),'-route','pipe','-parallel','1','-count','1'],cwd=s/'benchmarks/forkcompare',env=negv,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert neglog.stat().st_size<1024**2
text=neglog.read_text()+(negout.read_text() if negout.exists() else '')
assert r.returncode!=0 and 'O_DIRECT_NOSYNC' in text,(r.returncode,text[-3000:])
invalid=json.loads(negout.read_text());assert not invalid['success'] and invalid['cleanup_complete']
save('literal-rejection.json',{'result':'PASS','literal':'O_DIRECT_NOSYNC','returncode':r.returncode,'rejected':True,'cleanup_complete':True,'timed_arm':False})
variants=['both-off','commit0','commit0-method']
for v in variants:run(v,8,-2,8,preflight=True);run(v,1,-2,1,negative=True)
configs={v:json.loads((e/('effective-'+v+'.json')).read_text()) for v in variants}
allowed={'innodb_flush_log_at_trx_commit','innodb_flush_method','innodb_data_file_buffering','innodb_log_file_buffering','innodb_data_file_write_through','innodb_log_file_write_through'}
for v in variants[1:]:
 a=configs['both-off'];b=configs[v]
 for aa,bb in zip([a['root']]+a['children'],[b['root']]+b['children']):
  assert {k for k in aa if aa[k]!=bb[k]}<=allowed
save('preflight.json',{'result':'PASS','root_and_children_effective_values':'PASS','wrong_seed_controls':3,'literal_rejected':True,'primary_has_no_config_queries':True})
for p in [4,8]:
 for v in variants:run(v,p,-1,warmup=True)
for rep in range(5):
 for p in ([4,8] if rep%2==0 else [8,4]):
  shift=(rep+(1 if p==8 else 0))%3;order=variants[shift:]+variants[:shift]
  if rep%2:order=list(reversed(order))
  for v in order:run(v,p,rep)
save('complete.json',{'result':'PASS','measured_processes':30,'warmups':6,'preflight_processes':3,'negative_processes':3,'literal_invalid':1,'children_per_measured_process':48,'no_sample_removed':True,'controller_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'harness_source_commit':inputs['harness_source_commit'],'peak_workspace_bytes':guard.peak,'min_free_bytes':guard.minimum_free})
''';p.write_text(s)

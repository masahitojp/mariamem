from pathlib import Path
import json,subprocess,sys,os,hashlib,time
w=Path(__file__).resolve().parents[1];t=w/'temp';s=t/'source';e=w/'evidence';b=s/'benchmarks/forkcompare';sys.path.insert(0,str(s/'scripts'));from git_identity import require_commit;from experiment_disk import DiskGuard,run_guarded
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip();require_commit(s,head);assert not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True);require_commit(s,'1862f4a89397bddfa1820d835106d3437a438cf7')
assert head=='91eba5b76d92c8ff3ab018c5714008725987dfdd', 'use the pre-fix regression source for expected failure'
changed=subprocess.check_output(['git','diff','--name-only','1862f4a8',head],cwd=s,text=True).splitlines();assert all(n.startswith(('benchmarks/forkcompare/','benchmarks/forkstages/','benchmarks/defaultsettings/','benchmarks/bufferloadoff/','benchmarks/bufferbothoff/','benchmarks/bufferflush/','benchmarks/updatecapture/','benchmarks/updatenotify/')) for n in changed),changed
for n in ['cache','modcache','gotmp','scratch']:(t/n).mkdir(exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.startswith(('MARIAMEM_','MYSQLMEM_','GODEBUG'))};env.update(GOTOOLCHAIN='local',GOENV='off',GOWORK='off',GOFLAGS='',GOEXPERIMENT='',CGO_ENABLED='0',GOMAXPROCS='8',GOCACHE=str(t/'cache'),GOMODCACHE=str(t/'modcache'),GOTMPDIR=str(t/'gotmp'),TMPDIR=str(t/'scratch'),GOMEMLIMIT='3GiB',GOGC='50')
version=subprocess.check_output(['go','version'],env=env,text=True).strip();assert version=='go version go1.27.3 darwin/arm64'
subprocess.run(['python3',str(s/'benchmarks/updatenotify/overlay.py'),str(s),str(t/'overlay')],check=True)
guard=DiskGuard(w,12,6);start=time.monotonic()

with (e/'activation-before.log').open('w') as log:
 code=run_guarded(['go','test','-count=1','-run','^TestUWNotifyCrossesQueryStart$','-overlay',str(t/'overlay/overlay.json'),'./internal/generatedgo/code/base'],guard,cwd=s,env=env,output=log,timeout=120)
assert code != 0
assert 'signal namespace/address mismatch' in (e/'activation-before.log').read_text()
(e/'activation-before.json').write_text(json.dumps({'source_commit':head,'exit_code':code,'expected_failure':'signal namespace/address mismatch','result':'REPRODUCED'},indent=2)+'\n')
print('EXPECTED ACTIVATION PANIC REPRODUCED',head,flush=True)

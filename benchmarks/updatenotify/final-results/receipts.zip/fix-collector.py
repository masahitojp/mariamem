from pathlib import Path
import re
s=Path(__file__).resolve().parents[1]/'temp/source'
p=s/'benchmarks/updatenotify/trace.go.txt'; t=p.read_text()
t=t.replace('var uwMu sync.Mutex\nvar uwStates = map[*ThreadPool]*uwState{}','''// Registry lookup does not serialize independent instances' event append paths.
var uwStates sync.Map // *ThreadPool -> *uwState
func uwLookup(p *ThreadPool) *uwState {
 v, ok := uwStates.Load(p)
 if !ok { return nil }
 return v.(*uwState)
}''')
t=t.replace('type uwState struct {','type uwState struct {\n mu sync.Mutex\n emitted map[uint64]bool')
t=t.replace('type uwNotify struct {','type uwNotify struct {\n started int64\n ea uint64')
def replacefunc(name,body):
 global t
 pattern=r'func '+name+r'\([^\n]*\{.*?\n}\n'
 t,n=re.subn(pattern,lambda m:body+'\n',t,flags=re.S);assert n==1,name
replacefunc('UWBind','''func UWBind(m *Module, child int, ok bool) {
 if uwDir == "" || !ok { return }
 s := &uwState{Child:child,queries:map[int32]uwQuery{},waits:map[chan struct{}]*uwWait{},late:map[uint64]bool{},emitted:map[uint64]bool{}}
 if _,loaded := uwStates.LoadOrStore(m.Threads,s); loaded {panic("duplicate trace namespace")}
}''')
replacefunc('UWFlush','''func UWFlush(m *Module) {
 if uwDir == "" { return }
 value,ok := uwStates.LoadAndDelete(m.Threads)
 if !ok { return }
 s := value.(*uwState)
 s.mu.Lock()
 b,e := json.MarshalIndent(s,"","  ")
 s.mu.Unlock()
 if e != nil {panic(e)}
 if e = os.WriteFile(filepath.Join(uwDir,fmt.Sprintf("child-%03d.json",s.Child)),append(b,'\\n'),0600); e != nil {panic(e)}
}''')
# Look up namespace before acquiring its mutex; no cross-instance event lock.
for ret in ['return func() {}','return 0','return']:
 old='\tuwMu.Lock()\n\ts := uwStates[m.Threads]\n\tif s == nil {\n\t\tuwMu.Unlock()\n\t\t'+ret+'\n\t}'
 new='\ts := uwLookup(m.Threads)\n\tif s == nil {\n\t\t'+ret+'\n\t}\n\ts.mu.Lock()'
 t=t.replace(old,new)
for ret in ['return 0','return']:
 old='\tuwMu.Lock()\n\tdefer uwMu.Unlock()\n\ts := uwStates[m.Threads]\n\tif s == nil {\n\t\t'+ret+'\n\t}'
 new='\ts := uwLookup(m.Threads)\n\tif s == nil {\n\t\t'+ret+'\n\t}\n\ts.mu.Lock()\n\tdefer s.mu.Unlock()'
 t=t.replace(old,new)
replacefunc('UWNotifyBegin','''func UWNotifyBegin(p *ThreadPool, ea uint64, modules []*Module) uwNotify {
 if uwDir == "" { return uwNotify{} }
 ns := uwNow()
 s := uwLookup(p)
 if s == nil { return uwNotify{} }
 s.mu.Lock()
 defer s.mu.Unlock()
 s.next++
 thread := int32(0)
 if len(modules)==1 {
  if modules[0].Threads!=p {panic("wrong notifier namespace")}
  thread=modules[0].G1
 }
 // A token must exist even before a query starts: it can register a waiter
 // before this wake acquires parkMu. Record a dormant attempt only if matched.
 tok := uwNotify{s:s,id:s.next,thread:thread,started:ns,ea:ea}
 if len(s.queries)>0 {
  s.emitted[tok.id]=true
  uwAdd(s,uwEvent{NS:ns,Kind:"notify_attempt",Thread:thread,Notify:tok.id,EA:ea})
 }
 return tok
}''')
replacefunc('UWSignal','''func UWSignal(p *ThreadPool, ea uint64, ch chan struct{}, tok uwNotify, after bool) {
 if uwDir == "" { return }
 ns := uwNow()
 s := uwLookup(p)
 if s == nil { return }
 s.mu.Lock()
 defer s.mu.Unlock()
 w := s.waits[ch]
 if w == nil { return }
 if w.ea!=ea || tok.s!=s || tok.ea!=ea {panic("signal namespace/address mismatch")}
 if !s.emitted[tok.id] {
  s.emitted[tok.id]=true
  uwAdd(s,uwEvent{NS:tok.started,Kind:"notify_attempt",Thread:tok.thread,Notify:tok.id,EA:ea})
 }
 e := uwDecorate(uwEvent{NS:ns,Kind:"signal_before",Notify:tok.id},w)
 if after {e.Kind="signal_after"}
 if after && ns-w.start>=uwLong {s.late[tok.id]=true}
 uwAdd(s,e)
}''')
# NotifyEnd must use its token's instance, including after registry retirement.
t=t.replace('uwMu.Lock()\n\tlong := tok.s.late[tok.id]\n\tuwMu.Unlock()', '''tok.s.mu.Lock()
 if !tok.s.emitted[tok.id] {tok.s.mu.Unlock();return}
 long := tok.s.late[tok.id]
 tok.s.mu.Unlock()''')
t=t.replace('uwMu.Lock()\n\tuwAdd(tok.s, e)\n\tuwMu.Unlock()', 'tok.s.mu.Lock()\n\tuwAdd(tok.s, e)\n\ttok.s.mu.Unlock()')
t=t.replace('uwMu.', 's.mu.')
assert 'uwStates[' not in t and 'uwMu' not in t
p.write_text(t)
p=s/'benchmarks/updatenotify/trace-test.go.txt';t=p.read_text()
t=t.replace('uwMu.Lock()\n\t\tn := len(uwStates[a.Threads].waits)\n\t\tuwMu.Unlock()', 's := uwLookup(a.Threads)\n\t\ts.mu.Lock()\n\t\tn := len(s.waits)\n\t\ts.mu.Unlock()')
t=t.replace('uwStates[p]', 'uwLookup(p)')
t+='''
func TestUWIndependentInstanceAndDormantNotify(t *testing.T) {
 old:=uwDir
 uwDir=t.TempDir()
 defer func(){uwDir=old}()
 a,b:=&Module{Threads:&ThreadPool{}},&Module{Threads:&ThreadPool{}}
 UWBind(a,1,true); UWBind(b,2,true)
 defer UWFlush(a); defer UWFlush(b)
 state:=uwLookup(a.Threads)
 state.mu.Lock()
 done:=make(chan struct{})
 go func(){tok:=UWNotifyBegin(b.Threads,256,nil);UWNotifyEnd(tok,256,0);close(done)}()
 select {
 case <-done:
  state.mu.Unlock()
 case <-time.After(time.Second):
  state.mu.Unlock(); <-done; t.Fatal("independent instance blocked by trace mutex")
 }
 if len(uwLookup(b.Threads).Events)!=0 {t.Fatal("unmatched dormant notify should not fill trace")}
}
'''
p.write_text(t)

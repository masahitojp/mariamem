from pathlib import Path
import json,sys
E=Path(__file__).resolve().parent
old=json.loads((E/'previous-inputs.json').read_text());new=json.loads((E/'inputs.json').read_text())
fields=['product_source_commit','harness_source_commit','origin_guest_sha256','binary_sha256','toolchain','buildinfo','overlay']
checks={k:old[k]==new[k] for k in fields}
assert all(checks.values()),checks
result={'result':'PASS','previous_report_source_commit':'11cdb5df4f199af177348b7015b68296e94a4f31','identical_fields':checks,'binary_sha256':new['binary_sha256'],'separate_cohort':True,'old_receipts_relabelled':False}
if '--check' in sys.argv:assert result==json.loads((E/'repeat-identity.json').read_text())
else:(E/'repeat-identity.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS exact original source/overlay/binary/toolchain identity')

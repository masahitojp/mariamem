from pathlib import Path
import re,json,hashlib
E=Path(__file__).resolve().parent;S=E.parent/'temp/source';B=S/'internal/generatedgo/code'
s=(B/'generated.go').read_text();hextext=s.split('var wasm2goData_data_bin = []byte("',1)[1].split('")',1)[0];data=bytes.fromhex(hextext.replace('\\x',''));assert len(data)==9610331
wanted={16621,18164,17227,16806,17010,18025,18029,17047,17044,17169};result=[]
for path in B.glob('p*/p*_pure.go'):
 text=path.read_text()
 for m in re.finditer(r'^func Fn(\d+)\(',text,re.M):
  n=int(m[1])
  if n not in wanted:continue
  end=text.find('\nfunc ',m.end());frag=text[m.start():end if end!=-1 else len(text)];refs=[]
  for x in sorted(set(map(int,re.findall(r'int32\((\d+)\)',frag)))):
   off=x-8388608
   if not 0<=off<8967206:continue
   raw=data[off:off+min(300,8967206-off)].split(b'\0',1)[0]
   if len(raw)>=6 and all(32<=c<127 or c in [9,10,13] for c in raw):refs.append({'address':x,'text':raw.decode()})
  row={'fn':n,'file':str(path.relative_to(S)),'body_sha256':hashlib.sha256(frag.encode()).hexdigest(),'string_candidates':refs};result.append(row);print(n,refs)
(E/'static-string-candidates.json').write_text(json.dumps({'scope':'Static address/string references derived from pinned current generated source; candidates for source correspondence, not proven function names.','data_sha256':hashlib.sha256(data).hexdigest(),'data0_start':8388608,'functions':result},indent=2)+'\n')

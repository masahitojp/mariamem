package main
import("os";"fmt";"encoding/json";"debug/dwarf")
func u(b []byte,i *int)uint64{var v uint64;var shift uint;for{x:=b[*i];*i++;v|=uint64(x&127)<<shift;if x<128{return v};shift+=7}}
func str(b []byte,i *int)string{n:=int(u(b,i));s:=string(b[*i:*i+n]);*i+=n;return s}
func limits(b []byte,i *int){flags:=u(b,i);u(b,i);if flags&1!=0{u(b,i)}}
func main(){b,e:=os.ReadFile(os.Args[1]);if e!=nil{panic(e)};secs:=map[string][]byte{};imports:=0;var code []byte
 for i:=8;i<len(b);{id:=b[i];i++;n:=int(u(b,&i));data:=b[i:i+n];i+=n;j:=0
  switch id{case 0:name:=str(data,&j);secs[name]=data[j:];case 2:count:=u(data,&j);for k:=uint64(0);k<count;k++{str(data,&j);str(data,&j);kind:=data[j];j++;switch kind{case 0:u(data,&j);imports++;case 1:j++;limits(data,&j);case 2:limits(data,&j);case 3:j+=2;case 4:j++;u(data,&j);default:panic(kind)}};case 10:code=data}
 }
 type body struct{index int;begin,end uint64};var bodies []body;i:=0;count:=u(code,&i);for k:=0;k<int(count);k++{n:=int(u(code,&i));bodies=append(bodies,body{imports+k,uint64(i),uint64(i+n)});i+=n}
 d,e:=dwarf.New(secs[".debug_abbrev"],secs[".debug_aranges"],nil,secs[".debug_info"],secs[".debug_line"],nil,secs[".debug_ranges"],secs[".debug_str"]);if e!=nil{panic(e)};r:=d.Reader();var out []map[string]any
 for{en,e:=r.Next();if e!=nil{panic(e)};if en==nil{break};if en.Tag!=dwarf.TagSubprogram{continue};pc,ok:=en.Val(dwarf.AttrLowpc).(uint64);if !ok{continue};name,_:=en.Val(dwarf.AttrName).(string);link,_:=en.Val(dwarf.AttrLinkageName).(string);index:=-1;for _,f:=range bodies{if pc>=f.begin&&pc<f.end{index=f.index;break}};out=append(out,map[string]any{"name":name,"linkage":link,"low_pc":pc,"function_index":index})}
 enc:=json.NewEncoder(os.Stdout);enc.SetIndent("","  ");if e=enc.Encode(out);e!=nil{fmt.Fprintln(os.Stderr,e);os.Exit(1)}
}

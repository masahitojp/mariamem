from pathlib import Path
import os,sys,json,subprocess,hashlib
w=Path(__file__).resolve().parents[1];t=w/'temp';s=t/'source';e=w/'evidence';sys.path.insert(0,str(s/'scripts'));from experiment_disk import DiskGuard,run_guarded
inp=json.loads((e/'inputs.json').read_text());assert hashlib.sha256((t/'probe').read_bytes()).hexdigest()==inp['binary_sha256'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==inp['harness_source_commit'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True)
env={k:v for k,v in os.environ.items() if not k.startswith(('MARIAMEM_','MYSQLMEM_','GODEBUG','GOGC','GOMEMLIMIT','GOFLAGS','DEFAULT_SETTINGS_','UPDATE_WAIT_','FORKSTAGES_'))};env.update(GOMAXPROCS='8',GOGC='100',GOTOOLCHAIN='local',DEFAULT_SETTINGS_VARIANT='load-off');guard=DiskGuard(w,12,6);records=[]
def run(name,p,count,artificial=False,negative=False,preflight=False):
 scratch=t/name;scratch.mkdir();tmp=scratch/'tmp';tmp.mkdir();stacks=scratch/'stacks';stacks.mkdir();out=e/(name+'.json');v=dict(env,TMPDIR=str(tmp),UPDATE_WAIT_DIR=str(stacks))
 if artificial:v['UPDATE_WAIT_ARTIFICIAL']='1'
 if preflight:v['DEFAULT_SETTINGS_PREFLIGHT']='1'
 cmd=[str(t/'probe'),'-route','pipe','-parallel',str(p),'-count',str(count),'-out',str(out)]+(['-corrupt-seed'] if negative else [])
 with (e/(name+'.log')).open('w') as log:code=run_guarded(cmd,guard,cwd=s/'benchmarks/forkcompare',env=v,output=log,timeout=120)
 d=json.loads(out.read_text());assert d['cleanup_complete'] and d['root_closed_before_forks'] and not any(tmp.iterdir());assert d['parallel']==p and d['route']=='pipe' and d['gomaxprocs']==8
 if negative:assert code!=0 and not d['success'] and 'pristine oracle' in d['error'];assert not list(stacks.glob('*'))
 else:assert code==0 and d['success'] and len(d['samples'])==count and {x['index'] for x in d['samples']}==set(range(count)) and all(x['oracle'] and x['cleanup_complete'] for x in d['samples'])
 if preflight:
  for c in [d['config']]+[x['config'] for x in d['samples']]:assert c['innodb_buffer_pool_load_at_startup']=='OFF' and c['innodb_read_io_threads']=='1' and c['innodb_write_io_threads']=='2' and c['innodb_purge_threads']=='1' and c['innodb_buffer_pool_size']=='16777216'
 else:assert not d.get('config')
 captures=[]
 for meta in stacks.glob('*.json'):
  m=json.loads(meta.read_text());textfile=meta.with_suffix('.txt');data=textfile.read_text();m['whole_profile_inside_exec']=m['snapshot_begin_ms']>=100 and m['snapshot_end_ms']<=m['exec_return_ms'];m['usable']=m['whole_profile_inside_exec'] and m['labels_bound'] and not m['truncated'];assert m['artificial']==artificial;assert len(textfile.read_bytes())==m['bytes'] and m['bytes']<=2<<20
  (e/(name+'-'+meta.name)).write_text(json.dumps(m,indent=2)+'\n');(e/(name+'-'+textfile.name)).write_text(data);m['meta']=name+'-'+meta.name;m['text']=name+'-'+textfile.name;captures.append(m)
 assert len(captures)<=1
 if artificial:assert len(captures)==1 and captures[0]['usable'] and captures[0]['artificial']
 rec={'name':name,'parallel':p,'count':count,'artificial':artificial,'negative':negative,'preflight':preflight,'report':out.name,'exit_code':code,'captures':captures,'slow_update_children':[x['index'] for x in d['samples'] if x['update_ms']>100]};records.append(rec);(e/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,'PASS','updates>100',rec['slow_update_children'],'usable',[m['child'] for m in captures if m['usable']],flush=True);return rec
run('preflight',8,8,preflight=True);run('artificial-client',1,1,artificial=True);run('wrong-seed',1,1,negative=True)
result='NOT_REPRODUCED'
for i in range(3):
 r=run('natural-'+str(i),8,48)
 if any(c['usable'] and not c['artificial'] for c in r['captures']):result='NATURAL_UPDATE_CAPTURED';break
 if r['slow_update_children']:result='SLOW_UPDATE_WITHOUT_USABLE_CAPTURE'
(e/'complete.json').write_text(json.dumps({'result':result,'natural_processes':sum(r['name'].startswith('natural-') for r in records),'max_natural_processes':3,'no_extra_repeats':True,'controller_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'peak_workspace_bytes':guard.peak,'min_free_bytes':guard.minimum_free,'not_a_performance_comparison':True},indent=2)+'\n')

from pathlib import Path
import ctypes,json,os,subprocess,time,sys,hashlib,platform
w=Path(__file__).resolve().parents[1];t=w/'temp';s=t/'source';e=w/'evidence';sys.path.insert(0,str(s/'scripts'));from experiment_disk import DiskGuard,stop_group
class Usage(ctypes.Structure):
 _fields_=[('uuid',ctypes.c_uint8*16)]+[(n,ctypes.c_uint64) for n in ('user','system','idle','interrupt','pageins','wired','rss','footprint','start','exit')]
lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True);lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];lib.proc_pid_rusage.restype=ctypes.c_int
def rss(pid):
 u=Usage();assert lib.proc_pid_rusage(pid,0,ctypes.byref(u))==0;return u.rss

save=lambda name,v:(e/name).write_text(json.dumps(v,indent=2)+'\n')
inputs=json.loads((e/'inputs.json').read_text());assert hashlib.sha256((t/'probe').read_bytes()).hexdigest()==inputs['binary_sha256'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==inputs['harness_source_commit'] and not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True)
a=rss(os.getpid());b=int(subprocess.check_output(['ps','-o','rss=','-p',str(os.getpid())]))*1024;assert a>0 and abs(a-b)<8*1024**2
save('sampler.json',{'libproc_rss':a,'ps_rss':b,'sample_interval_ms':20,'platform':platform.platform(),'cpu':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'memory_bytes':int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),'logical_cpus':int(subprocess.check_output(['sysctl','-n','hw.ncpu'],text=True))})
env={k:v for k,v in os.environ.items() if not k.startswith(('MARIAMEM_','MYSQLMEM_','GODEBUG','GOMEMLIMIT','GOGC','GOFLAGS','FORKSTAGES_','DEFAULT_SETTINGS_','ISSUE116_'))};env.update(GOMAXPROCS='8',GOGC='100');guard=DiskGuard(w,12,6);records=[]
def run(variant,p,rep,count=48,negative=False,warmup=False,preflight=False):
 label=f'{variant}-p{p}-r{rep}'+('-negative' if negative else '-preflight' if preflight else '-warmup' if warmup else '')
 out=e/(label+'.json');sync=t/'sync'/label;scratch=t/'scratch'/label;sync.mkdir(parents=True);scratch.mkdir(parents=True);cmd=[str(t/'probe'),'-out',str(out),'-route','pipe','-parallel',str(p),'-count',str(count),'-sync-dir',str(sync)]+(['-corrupt-seed'] if negative else [])
 v=dict(env,TMPDIR=str(scratch),DEFAULT_SETTINGS_VARIANT=variant)
 if preflight:v['DEFAULT_SETTINGS_PREFLIGHT']='1'
 guard.check();process=None;samples=[];baseline=None;start=time.perf_counter_ns()
 with (e/(label+'.log')).open('w') as log:
  try:
   process=subprocess.Popen(cmd,cwd=s/'benchmarks/forkcompare',env=v,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);deadline=time.monotonic()+120
   while not (sync/'ready').exists():
    assert process.poll() is None and time.monotonic()<deadline,'ready/early-exit failure: '+label
    size=rss(process.pid);assert size<3*1024**3,'RSS limit before batch';time.sleep(.02)
   baseline=rss(process.pid);begin=time.monotonic();(sync/'go').write_text('go')
   while not (sync/'done').exists():
    assert time.monotonic()<deadline and process.poll() is None,'batch failure: '+label
    size=rss(process.pid);assert size<3*1024**3,'RSS limit during batch';samples.append({'offset_ms':(time.monotonic()-begin)*1000,'rss_bytes':size});time.sleep(.02)
   process.wait(timeout=30);code=process.returncode;wall=(time.perf_counter_ns()-start)/1e6
  finally:
   if process is not None:stop_group(process)
 guard.check();d=json.loads(out.read_text());assert d['cleanup_complete'] and not any(scratch.iterdir());assert d['root_closed_before_forks'] and d['gomaxprocs']==8 and d['parallel']==p and d['route']=='pipe'
 if negative:assert code!=0 and not d['success'] and 'pristine oracle' in d['error']
 else:
  assert code==0 and d['success'] and len(d['samples'])==count and {v['index'] for v in d['samples']}==set(range(count));assert all(v['oracle'] and v['cleanup_complete'] for v in d['samples'])
 if preflight:
  configs=[d['config']]+[v['config'] for v in d['samples']]
  for config in configs:
   expected={'innodb_buffer_pool_size':'16777216','innodb_buffer_pool_size_max':'16777216','innodb_log_buffer_size':'2097152','innodb_use_native_aio':'OFF','default_storage_engine':'InnoDB','innodb_read_io_threads':'1' if variant=='current' else '4','innodb_write_io_threads':'2' if variant=='current' else '4','innodb_purge_threads':'1' if variant=='current' else '4'}
   assert all(config[k].lower()==val.lower() for k,val in expected.items()),config
   if variant=='current':assert config['max_connections']=='10' and config['table_open_cache']=='32' and config['thread_cache_size']=='0'
   else:assert int(config['max_connections'])>10 and int(config['table_open_cache'])>32 and config['thread_cache_size']=='256'
  save('effective-'+variant+'.json',{'root':d['config'],'children':[v['config'] for v in d['samples']],'root_and_eight_child_assertions':'PASS'})
 else:assert not d.get('config') and all(not v.get('config') for v in d['samples'])
 events=sorted([(v['offset_ms'],1) for v in d['samples']]+[(v['offset_ms']+v['total_ms'],-1) for v in d['samples']]);active=peak=0
 for _,delta in events:active+=delta;peak=max(peak,active)
 assert active==0 and peak<=p
 if not negative:assert peak==p
 save(label+'-memory.json',{'baseline_rss_bytes':baseline,'sampled_peak_rss_bytes':max((v['rss_bytes'] for v in samples),default=None),'samples':samples,'interval_ms':20,'peak_active_children':peak})
 records.append({'variant':variant,'parallel':p,'repetition':rep,'count':count,'negative':negative,'warmup':warmup,'preflight':preflight,'report':out.name,'memory':label+'-memory.json','process_wall_ms':wall,'returncode':code,'binary_sha256':inputs['binary_sha256']});save('records.json',records);print(label,'PASS',round(d['batch_ms'],1),'ms',flush=True)
for v in ['current','bounded-default']:run(v,8,-2,8,preflight=True);run(v,1,-2,1,negative=True)
# These checks happen before ordinary runs; malformed selector cannot silently select a profile.
save('preflight.json',{'result':'PASS','root_and_children_effective_values':'PASS','wrong_seed_controls':2,'primary_has_no_config_queries':True})
for p in [4,8]:
 for v in ['current','bounded-default']:run(v,p,-1,warmup=True)
for rep in range(5):
 for p in ([4,8] if rep%2==0 else [8,4]):
  for v in (['current','bounded-default'] if (rep+(1 if p==8 else 0))%2==0 else ['bounded-default','current']):run(v,p,rep)
save('complete.json',{'result':'PASS','measured_processes':20,'warmups':4,'preflight_processes':2,'negative_processes':2,'children_per_measured_process':48,'no_sample_removed':True,'controller_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'harness_source_commit':inputs['harness_source_commit'],'peak_workspace_bytes':guard.peak,'min_free_bytes':guard.minimum_free})

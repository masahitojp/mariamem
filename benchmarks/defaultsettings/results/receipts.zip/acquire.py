from pathlib import Path
import subprocess,json,base64,hashlib
w=Path(__file__).resolve().parents[1];t=w/'temp';e=w/'evidence';s=t/'source';out=t/'upstream';out.mkdir(exist_ok=True)
plan=[('shyim/lite4mariadb','24be9371a2f6c71250a2356631ad6feab2280b02','wasm/lite4mariadb.c','lite4mariadb.c'),('MariaDB/server','83e909fc2a0dbc394b4b683fb3fa2d7dcf26cc5e','sql/sys_vars.cc','sys_vars.cc'),('MariaDB/server','83e909fc2a0dbc394b4b683fb3fa2d7dcf26cc5e','storage/innobase/handler/ha_innodb.cc','ha_innodb.cc')];receipt=[]
for repo,commit,path,name in plan:
 d=json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/contents/{path}?ref={commit}'],text=True));assert d['encoding']=='base64';b=base64.b64decode(d['content']);(out/name).write_bytes(b);receipt.append({'repository':repo,'source_commit':commit,'path':path,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
assert receipt[0]['sha256']==json.loads((s/'guest/input.json').read_text())['recipe_files_sha256']['wasm/lite4mariadb.c']
(e/'upstream-inputs.json').write_text(json.dumps(receipt,indent=2)+'\n');print('acquired verified recipe and pinned upstream defaults')

from pathlib import Path
import os,sys,json,subprocess,hashlib
w=Path(__file__).resolve().parents[1];t=w/'temp';s=t/'source';e=w/'evidence';sys.path.insert(0,str(s/'scripts'));from experiment_disk import DiskGuard,run_guarded
inp=json.loads((e/'inputs.json').read_text());assert hashlib.sha256((t/'probe').read_bytes()).hexdigest()==inp['binary_sha256'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==inp['harness_source_commit'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True)
env={k:v for k,v in os.environ.items() if not k.startswith(('MARIAMEM_','MYSQLMEM_','GODEBUG','GOGC','GOMEMLIMIT','GOFLAGS','FORKSTAGES_','ISSUE116_'))};env.update(GOMAXPROCS='8',GOGC='100',GOTOOLCHAIN='local');guard=DiskGuard(w,12,6);records=[]
def run(p,variant,mode,rep,count=48,negative=False):
 name=f'p{p}-{variant}-{mode}-r{rep}'+('-negative' if negative else '');scratch=t/name;scratch.mkdir();tr=scratch/'traces';tr.mkdir();tmp=scratch/'tmp';tmp.mkdir();out=e/(name+'.json');v=dict(env,TMPDIR=str(tmp),ISSUE116_SKIP_CLEAR='1' if variant=='candidate' else '0')
 if mode in ['diagnostic','pilot']:v.update(MARIAMEM_TIMING_DIR=str(tr),ISSUE116_READ_DIAG='1')
 cmd=[str(t/'probe'),'-route','pipe','-parallel',str(p),'-count',str(count),'-out',str(out)]+(['-corrupt-seed'] if negative else [])
 with (e/(name+'.log')).open('w') as log:code=run_guarded(cmd,guard,cwd=s/'benchmarks/forkcompare',env=v,output=log,timeout=120)
 d=json.loads(out.read_text());assert d['cleanup_complete'] and d['root_closed_before_forks'] and not any(tmp.iterdir());assert d['parallel']==p and d['route']=='pipe' and d['gomaxprocs']==8 and d['skip_clear']==(variant=='candidate')
 if negative:assert code!=0 and not d['success'] and 'pristine oracle' in d['error']
 else:assert code==0 and d['success'] and len(d['samples'])==count and {v['index'] for v in d['samples']}==set(range(count)) and all(v['oracle'] and v['cleanup_complete'] for v in d['samples'])
 if mode in ['diagnostic','pilot']:
  children={}
  for sample in d['samples']:
   i=sample['index'];ts={op:json.loads((tr/f'child-{i:03d}-{op}.json').read_text()) for op in ['fork','api_startup','startup']};events={v['name']:v['offset_ns'] for v in ts['startup']['events']};assert all(v in events for v in ['runtime/instance_begin','runtime/prepared_handles_ready','runtime/guest_execute_begin','ready_response_observed','end']);assert 'guest' in ts['startup'];ge={v['name'] for v in ts['startup']['guest']['events']};assert {'server_init_begin','server_init_complete','routine_schema_begin','routine_schema_complete'}<=ge;children[str(i)]=ts
  d['child_traces']=children;out.write_text(json.dumps(d,indent=2)+'\n')
 else:assert all(v==0 for v in d['read_stats'].values())
 events=sorted([(v['offset_ms'],1) for v in d['samples']]+[(v['offset_ms']+v['total_ms'],-1) for v in d['samples']]);active=peak=0
 for _,delta in events:active+=delta;peak=max(peak,active)
 assert active==0 and peak<=p
 if not negative:assert peak==p
 records.append({'parallel':p,'variant':variant,'mode':mode,'repetition':rep,'count':count,'negative':negative,'report':out.name,'exitcode':code,'peak_active':peak});(e/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,'PASS',round(d['batch_ms'],1),d['read_stats'] if mode=='pilot' else '',flush=True);return d
for variant in ['baseline','candidate']:run(8,variant,'pilot',-2,8);run(1,variant,'pilot',-2,1,True)
pilot=json.loads((e/'p8-candidate-pilot-r-2.json').read_text());bytes_per_child=(pilot['read_stats']['block_prefix_bytes']+pilot['read_stats']['mapped_prefix_bytes'])/8;passed=bytes_per_child>=1048576
(e/'mechanism.json').write_text(json.dumps({'result':'PASS' if passed else 'STOP_MECHANISM','avoided_bytes_per_child':bytes_per_child,'threshold':1048576,'routes':pilot['read_stats']},indent=2)+'\n')
if not passed:
 (e/'complete.json').write_text(json.dumps({'result':'STOP_MECHANISM','no_primary_campaign':True})+'\n');sys.exit(0)
for p in [4,8]:
 for v in ['baseline','candidate']:run(p,v,'warmup',-1)
for rep in range(5):
 for p in ([4,8] if rep%2==0 else [8,4]):
  for v in (['baseline','candidate'] if (rep+(1 if p==8 else 0))%2==0 else ['candidate','baseline']):run(p,v,'primary',rep)
for rep in range(3):
 for p in ([4,8] if rep%2==0 else [8,4]):
  for v in (['baseline','candidate'] if (rep+(1 if p==8 else 0))%2==0 else ['candidate','baseline']):run(p,v,'diagnostic',rep)
(e/'complete.json').write_text(json.dumps({'result':'PASS','primary_processes':20,'diagnostic_processes':12,'warmups':4,'pilots':4,'no_samples_removed':True,'controller_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'peak_workspace_bytes':guard.peak,'min_free_bytes':guard.minimum_free},indent=2)+'\n')

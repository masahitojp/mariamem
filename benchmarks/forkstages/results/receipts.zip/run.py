from pathlib import Path
import os,sys,json,subprocess,time,hashlib
w=Path(__file__).resolve().parents[1];t=w/'temp';s=t/'source';e=w/'evidence';sys.path.insert(0,str(s/'scripts'));from experiment_disk import DiskGuard,run_guarded
inp=json.loads((e/'inputs.json').read_text());assert hashlib.sha256((t/'probe').read_bytes()).hexdigest()==inp['binary_sha256'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==inp['harness_source_commit'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True)
env={k:v for k,v in os.environ.items() if not k.startswith(('MARIAMEM_','MYSQLMEM_','GODEBUG','GOGC','GOMEMLIMIT','GOFLAGS','FORKSTAGES_'))};env.update(GOMAXPROCS='8',GOGC='100',GOTOOLCHAIN='local');guard=DiskGuard(w,12,6);records=[]
def run(p,mode,rep,count=48,negative=False):
 name=f'p{p}-{mode}-r{rep}'+('-negative' if negative else '');scratch=t/name;scratch.mkdir();tr=scratch/'traces';tr.mkdir();tmp=scratch/'tmp';tmp.mkdir();out=e/(name+'.json');v=dict(env,TMPDIR=str(tmp))
 if mode=='traced':v['MARIAMEM_TIMING_DIR']=str(tr)
 if mode=='profile':v['FORKSTAGES_CPU']=str(e/(name+'.pprof'))
 cmd=[str(t/'probe'),'-route','pipe','-parallel',str(p),'-count',str(count),'-out',str(out)]+(['-corrupt-seed'] if negative else [])
 with (e/(name+'.log')).open('w') as log:code=run_guarded(cmd,guard,cwd=s/'benchmarks/forkcompare',env=v,output=log,timeout=120)
 d=json.loads(out.read_text());assert d['cleanup_complete'] and d['root_closed_before_forks'] and not any(tmp.iterdir());assert d['parallel']==p and d['route']=='pipe' and d['gomaxprocs']==8
 if negative:assert code!=0 and not d['success'] and 'pristine oracle' in d['error']
 else:assert code==0 and d['success'] and len(d['samples'])==count and {v['index'] for v in d['samples']}==set(range(count)) and all(v['oracle'] and v['cleanup_complete'] for v in d['samples'])
 if mode=='traced':
  children={}
  for sample in d['samples']:
   i=sample['index'];ts={op:json.loads((tr/f'child-{i:03d}-{op}.json').read_text()) for op in ['fork','api_startup','startup']};events={v['name']:v['offset_ns'] for v in ts['startup']['events']};assert all(v in events for v in ['runtime/instance_begin','runtime/prepared_handles_begin','runtime/prepared_handles_ready','runtime/reserve_begin','runtime/reserve_end','runtime/construct_begin','runtime/construct_end','runtime/guest_execute_begin','ready_response_observed','wire_listener_ready','end']);assert 'guest' in ts['startup'];ge={v['name'] for v in ts['startup']['guest']['events']};assert {'guest_main','server_init_begin','server_init_complete','routine_schema_begin','routine_schema_complete','ready_prepared'}<=ge;children[str(i)]=ts
  d['child_traces']=children;out.write_text(json.dumps(d,indent=2)+'\n')
 if mode=='profile':
  with (e/(name+'-cpu-top.txt')).open('w') as log:subprocess.run(['go','tool','pprof','-top','-nodecount=30','-sample_index=cpu',str(t/'probe'),str(e/(name+'.pprof'))],env=v,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=45)
 records.append({'parallel':p,'mode':mode,'repetition':rep,'count':count,'negative':negative,'report':out.name,'exitcode':code});(e/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,'PASS',round(d['batch_ms'],1),flush=True)
run(8,'traced',-2,8);run(1,'traced',-2,1,True)
for p in [1,4,8]:
 for mode in ['plain','traced']:run(p,mode,-1)
for rep in range(3):
 for p in ([1,4,8] if rep%2==0 else [8,4,1]):
  for mode in (['plain','traced'] if rep%2==0 else ['traced','plain']):run(p,mode,rep)
for p in [1,4,8]:run(p,'profile',0)
(e/'complete.json').write_text(json.dumps({'result':'PASS','timing_processes':18,'warmups':6,'profiles':3,'no_samples_removed':True,'controller_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'peak_workspace_bytes':guard.peak,'min_free_bytes':guard.minimum_free},indent=2)+'\n')
